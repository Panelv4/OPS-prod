import type { DashboardWidgetConfig, PlanTier, WorkspaceRole } from "@/db/schema";

export const ALL_ROLES: { id: WorkspaceRole; label: string; description: string }[] = [
  { id: "owner", label: "Owner", description: "Full workspace, security, and billing control" },
  {
    id: "administrator",
    label: "Administrator",
    description: "Full operational and user management access",
  },
  {
    id: "manager",
    label: "Manager",
    description: "Cross-module operations, approvals, projects, and reports",
  },
  {
    id: "hr_manager",
    label: "HR Manager",
    description: "Employee records, attendance, leave approvals, and payroll",
  },
  {
    id: "accountant",
    label: "Accountant",
    description: "Ledger, invoicing, payables, receivables, and tax reports",
  },
  {
    id: "salesperson",
    label: "Salesperson",
    description: "CRM customers, leads pipeline, quotations, and sales orders",
  },
  {
    id: "employee",
    label: "Employee",
    description: "Assigned projects, tasks, self-attendance, leave, and shared docs",
  },
];

export const ALL_PERMISSIONS = [
  "dashboard:view",
  "dashboard:customize",
  "crm:view",
  "crm:write",
  "crm:delete",
  "sales:view",
  "sales:write",
  "sales:refund",
  "finance:view",
  "finance:write",
  "finance:reverse",
  "hrms:view",
  "hrms:write",
  "hrms:confidential",
  "hrms:payroll",
  "inventory:view",
  "inventory:write",
  "inventory:adjust",
  "procurement:view",
  "procurement:write",
  "procurement:approve",
  "projects:view",
  "projects:write",
  "documents:view",
  "documents:write",
  "documents:restricted",
  "ai:use",
  "ai:configure",
  "automation:view",
  "automation:write",
  "automation:approve",
  "workspace:manage",
  "workspace:users",
  "workspace:billing",
  "workspace:audit",
] as const;

export type Permission = (typeof ALL_PERMISSIONS)[number];

export const DEFAULT_ROLE_PERMISSIONS: Record<WorkspaceRole, Permission[]> = {
  owner: [...ALL_PERMISSIONS],
  administrator: ALL_PERMISSIONS.filter((p) => p !== "workspace:billing"),
  manager: [
    "dashboard:view",
    "dashboard:customize",
    "crm:view",
    "crm:write",
    "sales:view",
    "sales:write",
    "finance:view",
    "hrms:view",
    "hrms:write",
    "inventory:view",
    "inventory:write",
    "inventory:adjust",
    "procurement:view",
    "procurement:write",
    "procurement:approve",
    "projects:view",
    "projects:write",
    "documents:view",
    "documents:write",
    "documents:restricted",
    "ai:use",
    "automation:view",
    "automation:write",
    "automation:approve",
    "workspace:audit",
  ],
  hr_manager: [
    "dashboard:view",
    "hrms:view",
    "hrms:write",
    "hrms:confidential",
    "hrms:payroll",
    "projects:view",
    "documents:view",
    "documents:write",
    "documents:restricted",
    "ai:use",
    "automation:view",
  ],
  accountant: [
    "dashboard:view",
    "crm:view",
    "sales:view",
    "sales:write",
    "sales:refund",
    "finance:view",
    "finance:write",
    "finance:reverse",
    "hrms:payroll",
    "inventory:view",
    "procurement:view",
    "procurement:write",
    "documents:view",
    "documents:write",
    "documents:restricted",
    "ai:use",
    "workspace:audit",
  ],
  salesperson: [
    "dashboard:view",
    "crm:view",
    "crm:write",
    "sales:view",
    "sales:write",
    "inventory:view",
    "projects:view",
    "documents:view",
    "documents:write",
    "ai:use",
  ],
  employee: [
    "dashboard:view",
    "hrms:view",
    "projects:view",
    "projects:write",
    "documents:view",
    "ai:use",
  ],
};

export function resolveUserPermissions(params: {
  role: WorkspaceRole;
  tenantRolePermissions?: Record<string, string[]> | null;
  customPermissions?: string[] | null;
}): Set<string> {
  if (params.role === "owner") {
    return new Set(ALL_PERMISSIONS);
  }
  const configured = params.tenantRolePermissions?.[params.role];
  const base =
    Array.isArray(configured) && configured.length > 0
      ? configured
      : DEFAULT_ROLE_PERMISSIONS[params.role] || [];
  const merged = new Set<string>(base);
  if (Array.isArray(params.customPermissions)) {
    for (const p of params.customPermissions) {
      merged.add(p);
    }
  }
  return merged;
}

export function hasPermission(
  permissions: Set<string>,
  required: Permission
): boolean {
  return permissions.has(required);
}

export function canAccessDocument(
  visibility: string,
  role: WorkspaceRole,
  permissions: Set<string>
): boolean {
  if (role === "owner" || role === "administrator") return true;
  if (visibility === "workspace") return permissions.has("documents:view");
  if (visibility === "managers") {
    return (
      role === "manager" ||
      role === "hr_manager" ||
      role === "accountant" ||
      permissions.has("documents:restricted")
    );
  }
  if (visibility === "hr_only") {
    return role === "hr_manager" || permissions.has("hrms:confidential");
  }
  if (visibility === "finance_only") {
    return role === "accountant" || permissions.has("finance:write");
  }
  return false;
}

export const DEFAULT_DASHBOARD_WIDGETS: DashboardWidgetConfig[] = [
  { id: "financial_kpis", label: "Financial Overview KPIs", visible: true, order: 1 },
  { id: "operations_kpis", label: "CRM, HRMS & Ops Pulse", visible: true, order: 2 },
  { id: "quick_actions", label: "Quick Business Actions", visible: true, order: 3 },
  { id: "revenue_chart", label: "Revenue, Expense & Profit Trends", visible: true, order: 4 },
  { id: "pipeline_chart", label: "Sales Pipeline & Conversion", visible: true, order: 5 },
  { id: "expense_chart", label: "Expense Categories & Customer Growth", visible: true, order: 6 },
  { id: "alerts_activity", label: "Inventory Alerts & Live Audit Feed", visible: true, order: 7 },
];

export interface PlanDefinition {
  id: PlanTier;
  name: string;
  priceInr: number | null;
  priceDisplay: string;
  period: string;
  tagline: string;
  aiTokenLimit: number;
  maxUsers: number;
  maxWorkflows: number;
  features: string[];
  highlighted?: boolean;
}

export const DEFAULT_PLANS: PlanDefinition[] = [
  {
    id: "community",
    name: "Community",
    priceInr: 0,
    priceDisplay: "₹0",
    period: "Free self-hosted",
    tagline: "Complete open business core for solo founders and local deployments.",
    aiTokenLimit: 50000,
    maxUsers: 5,
    maxWorkflows: 5,
    features: [
      "Self-hosted workspace isolation",
      "CRM, Sales, Invoicing & Ledger",
      "Projects, Tasks & Inventory core",
      "Up to 5 workspace members",
      "Deterministic AI business queries",
    ],
  },
  {
    id: "starter",
    name: "Starter",
    priceInr: 101,
    priceDisplay: "₹101",
    period: "Introductory offer",
    tagline: "Fast-track cloud onboarding for freelancers, studios, and early teams.",
    aiTokenLimit: 150000,
    maxUsers: 15,
    maxWorkflows: 15,
    features: [
      "Everything in Community",
      "Managed workspace & daily backups",
      "HRMS attendance & leave management",
      "Up to 15 workspace members",
      "15 active workflow automations",
      "150K monthly AI tokens",
    ],
  },
  {
    id: "pro",
    name: "Pro",
    priceInr: 499,
    priceDisplay: "₹499",
    period: "/ month",
    tagline: "Full operating system for growing agencies, e-commerce, and SMBs.",
    aiTokenLimit: 500000,
    maxUsers: 50,
    maxWorkflows: 50,
    highlighted: true,
    features: [
      "All 13 unified OpsPilot modules",
      "Jurisdiction-aware payroll & payslips",
      "Procurement, PO approvals & vendors",
      "OpsPilot AI reports & anomaly detection",
      "Natural-language workflow builder",
      "Up to 50 users & 500K AI tokens/mo",
    ],
  },
  {
    id: "business",
    name: "Business",
    priceInr: 1499,
    priceDisplay: "₹1,499",
    period: "/ month",
    tagline: "Multi-department governance, granular RBAC, and high-volume automation.",
    aiTokenLimit: 2500000,
    maxUsers: 250,
    maxWorkflows: 250,
    features: [
      "Everything in Pro",
      "Configurable role permission matrices",
      "Immutable compliance & audit trail export",
      "Document versioning & restricted vaults",
      "Bring-your-own LLM provider keys",
      "Up to 250 users & 2.5M AI tokens/mo",
    ],
  },
  {
    id: "custom",
    name: "Custom",
    priceInr: null,
    priceDisplay: "Custom",
    period: "Tailored agreement",
    tagline: "Dedicated infrastructure, custom integrations, migration & white-glove SLA.",
    aiTokenLimit: 10000000,
    maxUsers: 9999,
    maxWorkflows: 9999,
    features: [
      "Dedicated cloud or private VPC deployment",
      "Custom ERP workflows & API integrations",
      "Assisted historical data migration",
      "Dedicated onboarding & executive SLA",
      "Unlimited seats & custom AI quotas",
    ],
  },
];
