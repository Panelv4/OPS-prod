import { cookies } from "next/headers";
import { NextResponse } from "next/server";
import { and, eq, gt } from "drizzle-orm";
import { db } from "@/db";
import {
  sessions,
  tenants,
  users,
  workspaceMembers,
  type WorkspaceRole,
} from "@/db/schema";
import {
  generateSecureToken,
  getClientIp,
  sha256,
  verifyCsrf,
} from "@/lib/security";
import {
  hasPermission,
  resolveUserPermissions,
  type Permission,
} from "@/lib/permissions";
import { trackTenantApiCall } from "@/lib/audit";

export const SESSION_COOKIE_NAME = "opspilot_session";
const SESSION_TTL_DAYS = 14;

export interface AuthContext {
  user: {
    id: number;
    email: string;
    fullName: string;
    phone: string | null;
    emailVerified: boolean;
    notificationPrefs: typeof users.$inferSelect.notificationPrefs;
  };
  tenant: typeof tenants.$inferSelect;
  tenantId: number;
  role: WorkspaceRole;
  permissions: Set<string>;
  sessionId: number;
  csrfToken: string;
  ipAddress: string;
}

export class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

function parseSessionTokenFromRequest(request: Request): string | null {
  const cookieHeader = request.headers.get("cookie");
  if (cookieHeader) {
    const pairs = cookieHeader.split(";");
    for (const pair of pairs) {
      const idx = pair.indexOf("=");
      if (idx === -1) continue;
      const key = pair.slice(0, idx).trim();
      if (key === SESSION_COOKIE_NAME) {
        const val = decodeURIComponent(pair.slice(idx + 1).trim());
        if (val) return val;
      }
    }
  }
  // Fallback for embedded cross-origin preview iframes where third-party cookies are blocked
  const headerToken = request.headers.get("x-opspilot-session")?.trim();
  if (headerToken && /^[a-f0-9]{40,128}$/i.test(headerToken)) {
    return headerToken;
  }
  return null;
}

export async function createSession(params: {
  userId: number;
  tenantId: number;
  request: Request;
}): Promise<{ rawToken: string; csrfToken: string; expiresAt: Date }> {
  const rawToken = generateSecureToken(32);
  const tokenHash = sha256(rawToken);
  const csrfToken = generateSecureToken(24);
  const expiresAt = new Date(Date.now() + SESSION_TTL_DAYS * 24 * 60 * 60 * 1000);

  await db.insert(sessions).values({
    userId: params.userId,
    activeTenantId: params.tenantId,
    tokenHash,
    csrfToken,
    ipAddress: getClientIp(params.request),
    userAgent: (params.request.headers.get("user-agent") || "").slice(0, 250),
    expiresAt,
  });

  await db
    .update(users)
    .set({ lastLoginAt: new Date() })
    .where(eq(users.id, params.userId));

  return { rawToken, csrfToken, expiresAt };
}

export function attachSessionCookie(
  response: NextResponse,
  rawToken: string,
  expiresAt: Date,
  request?: Request
): void {
  const forwardedProto = request?.headers.get("x-forwarded-proto");
  const isHttps =
    forwardedProto === "https" ||
    (request?.url ? request.url.startsWith("https://") : false);

  response.cookies.set(SESSION_COOKIE_NAME, rawToken, {
    httpOnly: true,
    sameSite: isHttps ? "none" : "lax",
    secure: isHttps,
    partitioned: isHttps,
    path: "/",
    expires: expiresAt,
  });
}

export function clearSessionCookie(response: NextResponse, request?: Request): void {
  const forwardedProto = request?.headers.get("x-forwarded-proto");
  const isHttps =
    forwardedProto === "https" ||
    (request?.url ? request.url.startsWith("https://") : false);

  response.cookies.set(SESSION_COOKIE_NAME, "", {
    httpOnly: true,
    sameSite: isHttps ? "none" : "lax",
    secure: isHttps,
    partitioned: isHttps,
    path: "/",
    maxAge: 0,
  });
}

export async function getAuthContext(request?: Request): Promise<AuthContext | null> {
  let rawToken: string | null = null;
  if (request) {
    rawToken = parseSessionTokenFromRequest(request);
  } else {
    const store = await cookies();
    rawToken = store.get(SESSION_COOKIE_NAME)?.value ?? null;
  }
  if (!rawToken) return null;

  const tokenHash = sha256(rawToken);
  const now = new Date();

  const [sessionRow] = await db
    .select()
    .from(sessions)
    .where(and(eq(sessions.tokenHash, tokenHash), gt(sessions.expiresAt, now)))
    .limit(1);

  if (!sessionRow) return null;

  const [userRow] = await db
    .select()
    .from(users)
    .where(eq(users.id, sessionRow.userId))
    .limit(1);
  if (!userRow) return null;

  const [memberRow] = await db
    .select()
    .from(workspaceMembers)
    .where(
      and(
        eq(workspaceMembers.tenantId, sessionRow.activeTenantId),
        eq(workspaceMembers.userId, userRow.id),
        eq(workspaceMembers.status, "active")
      )
    )
    .limit(1);
  if (!memberRow) return null;

  const [tenantRow] = await db
    .select()
    .from(tenants)
    .where(eq(tenants.id, sessionRow.activeTenantId))
    .limit(1);
  if (!tenantRow) return null;

  const permissions = resolveUserPermissions({
    role: memberRow.role,
    tenantRolePermissions: tenantRow.rolePermissions,
    customPermissions: memberRow.customPermissions,
  });

  return {
    user: {
      id: userRow.id,
      email: userRow.email,
      fullName: userRow.fullName,
      phone: userRow.phone,
      emailVerified: userRow.emailVerified,
      notificationPrefs: userRow.notificationPrefs,
    },
    tenant: tenantRow,
    tenantId: tenantRow.id,
    role: memberRow.role,
    permissions,
    sessionId: sessionRow.id,
    csrfToken: sessionRow.csrfToken,
    ipAddress: request ? getClientIp(request) : "127.0.0.1",
  };
}

export async function requireAuth(
  request: Request,
  requiredPermission?: Permission
): Promise<AuthContext> {
  const ctx = await getAuthContext(request);
  if (!ctx) {
    throw new ApiError(401, "Authentication required. Please sign in.");
  }

  if (!verifyCsrf(request, ctx.csrfToken)) {
    throw new ApiError(403, "Invalid or missing CSRF verification token.");
  }

  if (requiredPermission && !hasPermission(ctx.permissions, requiredPermission)) {
    throw new ApiError(
      403,
      `Access denied: your role (${ctx.role}) does not have '${requiredPermission}' permission.`
    );
  }

  // Non-blocking tenant usage telemetry
  trackTenantApiCall(ctx.tenantId).catch(() => undefined);

  return ctx;
}

export function handleApiError(error: unknown): NextResponse {
  if (error instanceof ApiError) {
    return NextResponse.json({ error: error.message }, { status: error.status });
  }
  if (error && typeof error === "object" && "issues" in error) {
    const issues = (error as { issues: Array<{ message: string; path?: PropertyKey[] }> })
      .issues;
    const first = issues[0];
    const field = first?.path?.length ? `${first.path.join(".")}: ` : "";
    return NextResponse.json(
      { error: `${field}${first?.message || "Invalid input data."}` },
      { status: 400 }
    );
  }
  if (error instanceof Error) {
    // Handle PostgreSQL unique violation gracefully
    if ("code" in error && (error as { code?: string }).code === "23505") {
      return NextResponse.json(
        { error: "A record with this unique identifier already exists in your workspace." },
        { status: 409 }
      );
    }
    return NextResponse.json({ error: error.message }, { status: 400 });
  }
  return NextResponse.json(
    { error: "An unexpected server error occurred." },
    { status: 500 }
  );
}
