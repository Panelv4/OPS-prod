"use client";

const SESSION_TOKEN_KEY = "opspilot_iframe_session";
const CSRF_TOKEN_KEY = "opspilot_csrf_token";

export function saveClientSession(sessionToken?: string, csrfToken?: string): void {
  if (typeof window === "undefined") return;
  try {
    if (sessionToken) {
      window.sessionStorage.setItem(SESSION_TOKEN_KEY, sessionToken);
    }
    if (csrfToken) {
      window.sessionStorage.setItem(CSRF_TOKEN_KEY, csrfToken);
    }
  } catch {
    // sessionStorage unavailable
  }
}

export function getClientSessionToken(): string | null {
  if (typeof window === "undefined") return null;
  try {
    return window.sessionStorage.getItem(SESSION_TOKEN_KEY);
  } catch {
    return null;
  }
}

export function getClientCsrfToken(): string | null {
  if (typeof window === "undefined") return null;
  try {
    return window.sessionStorage.getItem(CSRF_TOKEN_KEY);
  } catch {
    return null;
  }
}

export function clearClientSession(): void {
  if (typeof window === "undefined") return;
  try {
    window.sessionStorage.removeItem(SESSION_TOKEN_KEY);
    window.sessionStorage.removeItem(CSRF_TOKEN_KEY);
  } catch {
    // ignore
  }
}
