import { db } from "@/db";
import { auditLogs, notifications, tenants } from "@/db/schema";
import { eq, sql } from "drizzle-orm";

export async function recordAuditLog(params: {
  tenantId: number;
  userId?: number | null;
  actorName: string;
  action: string;
  module: string;
  entityType: string;
  entityId?: string | number | null;
  summary: string;
  metadata?: Record<string, unknown>;
  ipAddress?: string | null;
}): Promise<void> {
  await db.insert(auditLogs).values({
    tenantId: params.tenantId,
    userId: params.userId ?? null,
    actorName: params.actorName,
    action: params.action,
    module: params.module,
    entityType: params.entityType,
    entityId: params.entityId != null ? String(params.entityId) : null,
    summary: params.summary,
    metadata: params.metadata ?? {},
    ipAddress: params.ipAddress ?? null,
  });
}

export async function createNotification(params: {
  tenantId: number;
  userId?: number | null;
  targetRole?: string | null;
  title: string;
  message: string;
  type?: "info" | "success" | "warning" | "alert" | "automation";
  link?: string | null;
}): Promise<void> {
  const emailConfigured = Boolean(process.env.SMTP_HOST);
  await db.insert(notifications).values({
    tenantId: params.tenantId,
    userId: params.userId ?? null,
    targetRole: params.targetRole ?? null,
    title: params.title,
    message: params.message,
    type: params.type ?? "info",
    link: params.link ?? null,
    isRead: false,
    emailQueued: emailConfigured,
  });
}

export async function trackTenantApiCall(tenantId: number): Promise<void> {
  await db
    .update(tenants)
    .set({ apiCallsCount: sql`${tenants.apiCallsCount} + 1` })
    .where(eq(tenants.id, tenantId));
}
