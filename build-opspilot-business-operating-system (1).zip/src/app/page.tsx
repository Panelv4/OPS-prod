"use client";

import React, { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  ArrowRight,
  Users,
  ReceiptText,
  Landmark,
  UserCheck,
  Package,
  Truck,
  FolderKanban,
  FileText,
  Sparkles,
  Workflow,
  ShieldCheck,
  BarChart3,
  Check,
  Building2,
} from "lucide-react";
import { OpsPilotLogo } from "@/components/brand/OpsPilotLogo";
import { ThemeToggleButton } from "@/components/providers/ThemeProvider";
import { DEFAULT_PLANS } from "@/lib/permissions";
import { saveClientSession } from "@/lib/client-session";

const MODULES = [
  {
    icon: Users,
    title: "CRM & Sales Pipeline",
    desc: "Customer 360 profiles, Kanban deal stages, follow-up tracking, and conversion intelligence.",
  },
  {
    icon: ReceiptText,
    title: "Sales & Invoicing",
    desc: "Quotations, sales orders, GST/VAT invoices, printable PDFs, partial payments, and refunds.",
  },
  {
    icon: Landmark,
    title: "Finance & Ledger",
    desc: "Immutable double-checked entries, receivables, payables, P&L statements, and reversing audits.",
  },
  {
    icon: UserCheck,
    title: "HRMS & Payroll",
    desc: "Employee directory, check-in attendance, leave approvals, and jurisdiction-aware payslips.",
  },
  {
    icon: Package,
    title: "Inventory Control",
    desc: "Product & service SKUs, stock valuation, traceable movement logs, and low-stock alerts.",
  },
  {
    icon: Truck,
    title: "Procurement & Vendors",
    desc: "Supplier profiles, PO approval gates, goods-received inventory sync, and vendor payouts.",
  },
  {
    icon: FolderKanban,
    title: "Projects & Tasks",
    desc: "Client project budgets, Kanban, List & Calendar task views, comments, and team alerts.",
  },
  {
    icon: FileText,
    title: "Document Vault",
    desc: "Role-scoped permissions, validated uploads, version history, previews, and expiry reminders.",
  },
  {
    icon: Sparkles,
    title: "OpsPilot Intelligence",
    desc: "Deterministic business AI over authorized data, executive reports, anomalies & receipt parsing.",
  },
  {
    icon: Workflow,
    title: "Workflow Automation",
    desc: "Event & scheduled automations, conditions, delays, approval gates, retries & NL draft builder.",
  },
  {
    icon: BarChart3,
    title: "Live Executive Analytics",
    desc: "Customizable KPI widgets, 6-month revenue/profit curves, pipeline velocity & cost categories.",
  },
  {
    icon: ShieldCheck,
    title: "Multi-Tenant Security",
    desc: "Strict workspace isolation, 7 configurable RBAC roles, CSRF protection, and audit trails.",
  },
];

export default function LandingPage() {
  const router = useRouter();
  const [launching, setLaunching] = useState(false);

  const launchDemo = async () => {
    setLaunching(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ demoRole: "owner" }),
      });
      if (res.ok) {
        const json = await res.json().catch(() => ({}));
        saveClientSession(json.sessionToken, json.csrfToken);
        router.push("/app");
        return;
      }
      router.push("/login");
    } finally {
      setLaunching(false);
    }
  };

  return (
    <div className="min-h-screen bg-white text-slate-900 dark:bg-[#0B0F17] dark:text-slate-100">
      {/* Top Navbar */}
      <header className="sticky top-0 z-30 border-b border-slate-200/80 bg-white/90 backdrop-blur-md dark:border-slate-800/80 dark:bg-[#0B0F17]/90">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6">
          <OpsPilotLogo size="md" />
          <nav className="hidden items-center gap-7 text-sm font-medium text-slate-600 md:flex dark:text-slate-300">
            <a href="#modules" className="hover:text-slate-900 dark:hover:text-white">
              Modules
            </a>
            <a href="#intelligence" className="hover:text-slate-900 dark:hover:text-white">
              Intelligence & Automation
            </a>
            <a href="#pricing" className="hover:text-slate-900 dark:hover:text-white">
              Pricing
            </a>
          </nav>
          <div className="flex items-center gap-2.5">
            <ThemeToggleButton />
            <Link
              href="/login"
              className="hidden text-sm font-medium text-slate-700 hover:text-slate-900 sm:inline-block px-2.5 py-1.5 dark:text-slate-300 dark:hover:text-white"
            >
              Sign in
            </Link>
            <Link href="/register" className="op-btn-primary text-xs sm:text-sm">
              Start Free
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden border-b border-slate-200/70 pt-16 pb-20 sm:pt-24 sm:pb-28 dark:border-slate-800/70">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <div className="mx-auto max-w-3xl text-center">
            <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-slate-200 bg-slate-50 px-3.5 py-1 text-xs font-medium text-slate-700 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300">
              <Building2 className="h-3.5 w-3.5 text-indigo-600 dark:text-indigo-400" />
              <span>Multi-Tenant AI Business Operating System</span>
            </div>
            <h1 className="text-4xl font-bold tracking-tight text-slate-900 sm:text-6xl sm:leading-[1.08] dark:text-white">
              Your Entire Business.
              <br />
              <span className="text-slate-500 dark:text-slate-400">
                One Operating System.
              </span>
            </h1>
            <p className="mx-auto mt-6 max-w-2xl text-base leading-relaxed text-slate-600 sm:text-lg dark:text-slate-400">
              Replace twelve disconnected subscriptions with one calm, unified workspace.
              OpsPilot brings CRM, invoicing, immutable finance, HRMS payroll, inventory,
              procurement, projects, documents, verified AI, and workflow automation
              together.
            </p>
            <div className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row">
              <Link
                href="/register"
                className="op-btn-primary h-11 w-full px-6 text-sm sm:w-auto"
              >
                Create Business Workspace
                <ArrowRight className="h-4 w-4" />
              </Link>
              <button
                type="button"
                onClick={launchDemo}
                disabled={launching}
                className="op-btn-secondary h-11 w-full px-6 text-sm sm:w-auto"
              >
                {launching ? "Opening Demo Workspace…" : "Explore Live Demo Workspace"}
              </button>
            </div>
            <p className="mt-4 text-xs text-slate-500 dark:text-slate-500">
              Self-host free forever on Community · Cloud plans start at ₹101 · Core ERP
              works with zero external AI keys
            </p>
          </div>

          {/* Crisp Executive Architecture Preview Window */}
          <div className="mt-14 rounded-2xl border border-slate-200 bg-slate-50/70 p-2 shadow-xl shadow-slate-900/[0.04] dark:border-slate-800 dark:bg-slate-900/50">
            <div className="rounded-xl border border-slate-200 bg-white overflow-hidden dark:border-slate-800 dark:bg-[#111827]">
              <div className="flex items-center justify-between border-b border-slate-100 bg-slate-50/80 px-4 py-2.5 dark:border-slate-800 dark:bg-slate-900/80">
                <div className="flex items-center gap-1.5">
                  <span className="h-2.5 w-2.5 rounded-full bg-slate-300 dark:bg-slate-700" />
                  <span className="h-2.5 w-2.5 rounded-full bg-slate-300 dark:bg-slate-700" />
                  <span className="h-2.5 w-2.5 rounded-full bg-slate-300 dark:bg-slate-700" />
                </div>
                <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                  meridian-ops · Executive Overview · Live Multi-Tenant Ledger
                </span>
                <span className="rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-semibold text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300">
                  Isolated
                </span>
              </div>
              <div className="grid grid-cols-2 gap-px bg-slate-100 sm:grid-cols-4 dark:bg-slate-800">
                {[
                  { k: "Posted Revenue (6M)", v: "₹55,51,000", s: "+18.4% net trajectory" },
                  { k: "Operating Profit", v: "₹30,12,800", s: "54.3% verified margin" },
                  { k: "Active CRM Pipeline", v: "₹34,30,000", s: "5 active opportunities" },
                  { k: "Automations Active", v: "4 Live · 1 Draft", s: "Approval-gated engine" },
                ].map((m) => (
                  <div key={m.k} className="bg-white p-5 dark:bg-[#111827]">
                    <div className="text-xs font-medium text-slate-500 dark:text-slate-400">
                      {m.k}
                    </div>
                    <div className="mt-1.5 text-xl font-semibold text-slate-900 tabular sm:text-2xl dark:text-white">
                      {m.v}
                    </div>
                    <div className="mt-1 text-xs text-emerald-600 dark:text-emerald-400">
                      {m.s}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 12 Unified Modules */}
      <section id="modules" className="py-20 sm:py-24">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <div className="max-w-2xl">
            <p className="text-xs font-semibold tracking-wider text-indigo-600 uppercase dark:text-indigo-400">
              Complete Modular Architecture
            </p>
            <h2 className="mt-2 text-3xl font-bold tracking-tight text-slate-900 dark:text-white">
              Every department wired to a single source of truth.
            </h2>
            <p className="mt-3 text-base text-slate-600 dark:text-slate-400">
              Designed for small businesses, agencies, e-commerce brands, startups,
              consulting firms, and growing teams.
            </p>
          </div>

          <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {MODULES.map((mod) => {
              const Icon = mod.icon;
              return (
                <div
                  key={mod.title}
                  className="op-card p-5 transition-colors hover:border-slate-300 dark:hover:border-slate-700"
                >
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg border border-slate-200 bg-slate-50 text-slate-800 dark:border-slate-800 dark:bg-slate-900 dark:text-indigo-400">
                    <Icon className="h-4 w-4" />
                  </div>
                  <h3 className="mt-4 text-sm font-semibold text-slate-900 dark:text-white">
                    {mod.title}
                  </h3>
                  <p className="mt-1.5 text-xs leading-relaxed text-slate-600 dark:text-slate-400">
                    {mod.desc}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Intelligence & Automation Split */}
      <section
        id="intelligence"
        className="border-y border-slate-200/80 bg-slate-50/70 py-20 dark:border-slate-800/80 dark:bg-[#0E1420]"
      >
        <div className="mx-auto grid max-w-6xl gap-8 px-4 sm:px-6 lg:grid-cols-2">
          <div className="op-card p-7">
            <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-indigo-600 dark:text-indigo-400">
              <Sparkles className="h-4 w-4" />
              OPSPILOT INTELLIGENCE
            </div>
            <h3 className="mt-2 text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
              AI that never invents a single rupee.
            </h3>
            <p className="mt-3 text-sm leading-relaxed text-slate-600 dark:text-slate-400">
              Every question executes deterministic, permission-scoped PostgreSQL queries
              first. Ask for overdue invoices, anomaly sweeps, executive briefings, or
              receipt extraction — with mandatory human confirmation before any action runs.
            </p>
            <div className="mt-5 space-y-2 rounded-xl border border-slate-200 bg-slate-50 p-4 text-xs dark:border-slate-800 dark:bg-slate-900/70">
              <div className="font-medium text-slate-900 dark:text-white">
                &ldquo;Which customers have overdue payments and which SKUs are low?&rdquo;
              </div>
              <div className="text-slate-600 dark:text-slate-400">
                → Verified via <code className="text-indigo-600 dark:text-indigo-400">get_overdue_invoices</code> &{" "}
                <code className="text-indigo-600 dark:text-indigo-400">get_low_stock_products</code> · RBAC checked · AES-256 encrypted BYO LLM keys supported.
              </div>
            </div>
          </div>

          <div className="op-card p-7">
            <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-indigo-600 dark:text-indigo-400">
              <Workflow className="h-4 w-4" />
              WORKFLOW AUTOMATION ENGINE
            </div>
            <h3 className="mt-2 text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
              Describe rules in plain English. Approve to activate.
            </h3>
            <p className="mt-3 text-sm leading-relaxed text-slate-600 dark:text-slate-400">
              Combine event triggers, threshold conditions, delays, multi-step actions,
              automatic retries, and manager sign-off gates with full execution history.
            </p>
            <div className="mt-5 space-y-2 text-xs">
              {[
                "WHEN lead.created → Notify assigned salesperson & create follow-up task",
                "WHEN invoice.overdue → Dispatch collection reminder & alert accountant",
                "WHEN stock.low → Alert inventory manager & log restock requirement",
              ].map((rule) => (
                <div
                  key={rule}
                  className="rounded-lg border border-slate-200 bg-slate-50 px-3.5 py-2 font-medium text-slate-700 dark:border-slate-800 dark:bg-slate-900/70 dark:text-slate-300"
                >
                  {rule}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Commercial Pricing */}
      <section id="pricing" className="py-20 sm:py-24">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <div className="mx-auto max-w-2xl text-center">
            <p className="text-xs font-semibold tracking-wider text-indigo-600 uppercase dark:text-indigo-400">
              Transparent Commercial Pricing
            </p>
            <h2 className="mt-2 text-3xl font-bold tracking-tight text-slate-900 dark:text-white">
              Start free or onboard your whole business for ₹101.
            </h2>
            <p className="mt-3 text-sm text-slate-600 dark:text-slate-400">
              Self-host Community at zero cost, or scale on managed OpsPilot Cloud with
              configurable plans and enterprise add-ons.
            </p>
          </div>

          <div className="mt-12 grid gap-4 md:grid-cols-3 lg:grid-cols-5">
            {DEFAULT_PLANS.map((plan) => (
              <div
                key={plan.id}
                className={`flex flex-col rounded-2xl border p-5 ${
                  plan.highlighted
                    ? "border-slate-900 bg-slate-900 text-white shadow-lg dark:border-indigo-500 dark:bg-indigo-950/40"
                    : "border-slate-200 bg-white dark:border-slate-800 dark:bg-[#111827]"
                }`}
              >
                <div className="text-sm font-semibold">{plan.name}</div>
                <div className="mt-3 flex items-baseline gap-1 tabular">
                  <span className="text-3xl font-bold tracking-tight">
                    {plan.priceDisplay}
                  </span>
                </div>
                <div
                  className={`text-xs ${
                    plan.highlighted
                      ? "text-slate-300"
                      : "text-slate-500 dark:text-slate-400"
                  }`}
                >
                  {plan.period}
                </div>
                <p
                  className={`mt-3 text-xs leading-relaxed ${
                    plan.highlighted
                      ? "text-slate-300"
                      : "text-slate-600 dark:text-slate-400"
                  }`}
                >
                  {plan.tagline}
                </p>
                <ul className="mt-4 flex-1 space-y-2 text-xs">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-start gap-2">
                      <Check
                        className={`mt-0.5 h-3.5 w-3.5 shrink-0 ${
                          plan.highlighted
                            ? "text-indigo-300"
                            : "text-emerald-600 dark:text-emerald-400"
                        }`}
                      />
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>
                <Link
                  href="/register"
                  className={`mt-6 inline-flex h-9 items-center justify-center rounded-lg text-xs font-semibold transition-colors ${
                    plan.highlighted
                      ? "bg-white text-slate-900 hover:bg-slate-100"
                      : "border border-slate-200 bg-slate-50 text-slate-900 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-white dark:hover:bg-slate-700"
                  }`}
                >
                  {plan.id === "custom" ? "Contact Sales" : `Choose ${plan.name}`}
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-200 py-10 dark:border-slate-800">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-4 sm:flex-row sm:px-6">
          <OpsPilotLogo size="sm" />
          <p className="text-xs text-slate-500 dark:text-slate-400">
            © {new Date().getFullYear()} OpsPilot. Your Entire Business. One Operating
            System.
          </p>
          <div className="flex items-center gap-5 text-xs font-medium text-slate-600 dark:text-slate-400">
            <Link href="/login" className="hover:text-slate-900 dark:hover:text-white">
              Sign In
            </Link>
            <Link href="/register" className="hover:text-slate-900 dark:hover:text-white">
              Register Workspace
            </Link>
            <button
              type="button"
              onClick={launchDemo}
              className="hover:text-slate-900 dark:hover:text-white"
            >
              Live Demo
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
