"use client";

import React, { useCallback, useEffect, useState } from "react";
import { Check, Sliders } from "lucide-react";
import { useWorkspace } from "@/components/providers/WorkspaceProvider";
import {
  formatBytes,
  Modal,
  PageHeader,
  StatCard,
} from "@/components/ui/primitives";
import type { PlanDefinition } from "@/lib/permissions";

interface BillingPayload {
  currentPlan: string;
  billingStatus: string;
  canManageBilling: boolean;
  plans: PlanDefinition[];
  addons: Array<{
    id: string;
    name: string;
    priceLabel: string;
    description: string;
  }>;
  usage: {
    seatsUsed: number;
    seatsLimit: number;
    workflowsUsed: number;
    workflowsLimit: number;
    aiTokensUsed: number;
    aiTokensLimit: number;
    storageBytesUsed: number;
    apiCallsCount: number;
  };
  history: Array<{
    id: number;
    previousPlan: string;
    newPlan: string;
    amountInr: number;
    description: string;
    actorName: string;
    createdAt: string;
  }>;
}

export default function BillingPage() {
  const { apiFetch, toast, refreshSession } = useWorkspace();
  const [data, setData] = useState<BillingPayload | null>(null);
  const [cfgOpen, setCfgOpen] = useState(false);
  const [cfgPlan, setCfgPlan] = useState<"starter" | "pro" | "business">("pro");
  const [cfgPrice, setCfgPrice] = useState("499");

  const load = useCallback(async () => {
    try {
      const res = await apiFetch<BillingPayload>("/api/billing");
      setData(res);
    } catch (err) {
      toast(err instanceof Error ? err.message : "Failed to load billing", "error");
    }
  }, [apiFetch, toast]);

  useEffect(() => {
    load();
  }, [load]);

  const switchPlan = async (plan: string) => {
    try {
      await apiFetch("/api/billing", {
        method: "POST",
        body: JSON.stringify({ action: "change_plan", plan }),
      });
      toast(`Workspace subscription updated to ${plan.toUpperCase()}`);
      await load();
      await refreshSession();
    } catch (err) {
      toast(err instanceof Error ? err.message : "Plan update failed", "error");
    }
  };

  const saveCustomPrice = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await apiFetch("/api/billing", {
        method: "POST",
        body: JSON.stringify({
          action: "configure_pricing",
          planId: cfgPlan,
          priceInr: Number(cfgPrice),
        }),
      });
      setCfgOpen(false);
      toast("Updated configurable plan pricing");
      load();
    } catch (err) {
      toast(err instanceof Error ? err.message : "Error", "error");
    }
  };

  if (!data) {
    return <div className="text-xs text-slate-500">Loading billing…</div>;
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Billing, Usage & Commercial Plans"
        description="Tenant-level usage telemetry, self-hosted Community & managed OpsPilot Cloud tiers"
        actions={
          data.canManageBilling && (
            <button
              type="button"
              onClick={() => setCfgOpen(true)}
              className="op-btn-secondary text-xs"
            >
              <Sliders className="h-3.5 w-3.5" /> Configure Plan Pricing
            </button>
          )
        }
      />

      {/* Tenant Usage Telemetry */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          label="Team Seats"
          value={`${data.usage.seatsUsed} / ${data.usage.seatsLimit}`}
          subtext={`Active plan: ${data.currentPlan.toUpperCase()}`}
        />
        <StatCard
          label="AI Token Meter"
          value={data.usage.aiTokensUsed.toLocaleString()}
          subtext={`Limit: ${data.usage.aiTokensLimit.toLocaleString()} / mo`}
        />
        <StatCard
          label="Workflows Configured"
          value={`${data.usage.workflowsUsed} / ${data.usage.workflowsLimit}`}
          subtext="Event & scheduled automations"
        />
        <StatCard
          label="Vault Storage & API"
          value={formatBytes(data.usage.storageBytesUsed)}
          subtext={`${data.usage.apiCallsCount.toLocaleString()} workspace API calls`}
        />
      </div>

      {/* Plans Grid */}
      <div className="grid gap-4 md:grid-cols-3 lg:grid-cols-5">
        {data.plans.map((p) => {
          const isCurrent = p.id === data.currentPlan;
          return (
            <div
              key={p.id}
              className={`flex flex-col rounded-2xl border p-5 ${
                isCurrent
                  ? "border-indigo-600 ring-1 ring-indigo-600 bg-white dark:bg-[#111827]"
                  : "border-slate-200 bg-white dark:border-slate-800 dark:bg-[#111827]"
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold text-slate-900 dark:text-white">
                  {p.name}
                </span>
                {isCurrent && (
                  <span className="rounded-full bg-indigo-600 px-2 py-0.5 text-[10px] font-semibold text-white">
                    Current
                  </span>
                )}
              </div>
              <div className="mt-3 text-2xl font-bold tabular text-slate-900 dark:text-white">
                {p.priceDisplay}
              </div>
              <div className="text-[11px] text-slate-500">{p.period}</div>
              <ul className="mt-4 flex-1 space-y-1.5 text-xs text-slate-600 dark:text-slate-400">
                {p.features.map((f) => (
                  <li key={f} className="flex items-start gap-1.5">
                    <Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-600" />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
              {data.canManageBilling && (
                <button
                  type="button"
                  disabled={isCurrent}
                  onClick={() => switchPlan(p.id)}
                  className={`mt-5 h-9 rounded-lg text-xs font-semibold ${
                    isCurrent
                      ? "bg-slate-100 text-slate-400 cursor-default dark:bg-slate-800"
                      : "op-btn-primary w-full"
                  }`}
                >
                  {isCurrent
                    ? "Active Plan"
                    : p.id === "custom"
                    ? "Request Custom"
                    : `Select ${p.name}`}
                </button>
              )}
            </div>
          );
        })}
      </div>

      {/* Add-ons & History */}
      <div className="grid gap-6 lg:grid-cols-2">
        <div className="op-card p-5">
          <h3 className="mb-3 text-sm font-semibold text-slate-900 dark:text-white">
            Enterprise Add-Ons & Services
          </h3>
          <div className="space-y-2.5">
            {data.addons.map((ad) => (
              <div
                key={ad.id}
                className="flex items-start justify-between gap-3 rounded-xl border border-slate-200 p-3 text-xs dark:border-slate-800"
              >
                <div>
                  <div className="font-semibold text-slate-900 dark:text-white">
                    {ad.name}
                  </div>
                  <div className="text-slate-500">{ad.description}</div>
                </div>
                <span className="shrink-0 font-semibold tabular text-indigo-600 dark:text-indigo-400">
                  {ad.priceLabel}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="op-card p-5">
          <h3 className="mb-3 text-sm font-semibold text-slate-900 dark:text-white">
            Subscription Audit History
          </h3>
          <div className="divide-y divide-slate-100 text-xs dark:divide-slate-800">
            {data.history.map((h) => (
              <div key={h.id} className="py-2.5">
                <div className="font-medium text-slate-900 dark:text-white">
                  {h.description}
                </div>
                <div className="text-[11px] text-slate-500">
                  {h.actorName} · {new Date(h.createdAt).toLocaleDateString()}
                </div>
              </div>
            ))}
            {data.history.length === 0 && (
              <p className="py-4 text-slate-500">No plan changes recorded yet.</p>
            )}
          </div>
        </div>
      </div>

      <Modal
        open={cfgOpen}
        onClose={() => setCfgOpen(false)}
        title="Configure Commercial Tier Pricing"
        subtitle="Adjust workspace plan pricing without code changes"
      >
        <form onSubmit={saveCustomPrice} className="space-y-3">
          <div>
            <label className="op-label">Tier</label>
            <select
              value={cfgPlan}
              onChange={(e) =>
                setCfgPlan(e.target.value as "starter" | "pro" | "business")
              }
              className="op-input"
            >
              <option value="starter">Starter (Default ₹101)</option>
              <option value="pro">Pro (Default ₹499)</option>
              <option value="business">Business (Default ₹1,499)</option>
            </select>
          </div>
          <div>
            <label className="op-label">Configured Price (INR)</label>
            <input
              type="number"
              min="0"
              required
              value={cfgPrice}
              onChange={(e) => setCfgPrice(e.target.value)}
              className="op-input tabular"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setCfgOpen(false)}
              className="op-btn-secondary"
            >
              Cancel
            </button>
            <button type="submit" className="op-btn-primary">
              Save Price
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
