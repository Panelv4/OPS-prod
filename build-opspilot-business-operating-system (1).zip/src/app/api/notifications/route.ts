import { NextResponse } from "next/server";
import { z } from "zod";
import { and, desc, eq, isNull, or } from "drizzle-orm";
import { db } from "@/db";
import { notifications } from "@/db/schema";
import { handleApiError, requireAuth } from "@/lib/auth";

export async function GET(request: Request) {
  try {
    const ctx = await requireAuth(request);
    const isAdmin = ctx.role === "owner" || ctx.role === "administrator";

    const rows = await db
      .select()
      .from(notifications)
      .where(
        and(
          eq(notifications.tenantId, ctx.tenantId),
          or(isNull(notifications.userId), eq(notifications.userId, ctx.user.id)),
          isAdmin
            ? eq(notifications.tenantId, ctx.tenantId)
            : or(
                isNull(notifications.targetRole),
                eq(notifications.targetRole, ctx.role)
              )
        )
      )
      .orderBy(desc(notifications.createdAt))
      .limit(40);

    return NextResponse.json({
      notifications: rows,
      unreadCount: rows.filter((n) => !n.isRead).length,
      prefs: ctx.user.notificationPrefs,
      smtpConfigured: Boolean(process.env.SMTP_HOST),
    });
  } catch (err) {
    return handleApiError(err);
  }
}

const patchNotifSchema = z.object({
  id: z.number().int().positive().optional(),
  markAllRead: z.boolean().optional(),
});

export async function PATCH(request: Request) {
  try {
    const ctx = await requireAuth(request);
    const body = patchNotifSchema.parse(await request.json());

    if (body.markAllRead) {
      await db
        .update(notifications)
        .set({ isRead: true })
        .where(eq(notifications.tenantId, ctx.tenantId));
      return NextResponse.json({ ok: true });
    }

    if (body.id) {
      await db
        .update(notifications)
        .set({ isRead: true })
        .where(
          and(
            eq(notifications.id, body.id),
            eq(notifications.tenantId, ctx.tenantId)
          )
        );
    }

    return NextResponse.json({ ok: true });
  } catch (err) {
    return handleApiError(err);
  }
}
