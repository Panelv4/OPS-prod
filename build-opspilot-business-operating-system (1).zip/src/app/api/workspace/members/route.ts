import { NextResponse } from "next/server";
import { z } from "zod";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import {
  workspaceInvitations,
  workspaceMembers,
} from "@/db/schema";
import { ApiError, handleApiError, requireAuth } from "@/lib/auth";
import { generateSecureToken, sha256 } from "@/lib/security";
import { recordAuditLog } from "@/lib/audit";

const roleEnum = z.enum([
  "owner",
  "administrator",
  "manager",
  "hr_manager",
  "accountant",
  "salesperson",
  "employee",
]);

const inviteSchema = z.object({
  email: z.string().email(),
  role: roleEnum.default("employee"),
});

export async function POST(request: Request) {
  try {
    const ctx = await requireAuth(request, "workspace:users");
    const body = inviteSchema.parse(await request.json());
    const email = body.email.trim().toLowerCase();

    if (body.role === "owner" && ctx.role !== "owner") {
      throw new ApiError(403, "Only a workspace Owner can assign the Owner role.");
    }

    const inviteCode = `INV-${generateSecureToken(8).toUpperCase()}`;
    const tokenHash = sha256(inviteCode);
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);

    const [invite] = await db
      .insert(workspaceInvitations)
      .values({
        tenantId: ctx.tenantId,
        email,
        role: body.role,
        tokenHash,
        inviteCode,
        invitedByUserId: ctx.user.id,
        status: "pending",
        expiresAt,
      })
      .returning();

    await recordAuditLog({
      tenantId: ctx.tenantId,
      userId: ctx.user.id,
      actorName: ctx.user.fullName,
      action: "member.invited",
      module: "workspace",
      entityType: "invitation",
      entityId: invite.id,
      summary: `Invited ${email} to join workspace as ${body.role}`,
      ipAddress: ctx.ipAddress,
    });

    return NextResponse.json(
      {
        invitation: {
          id: invite.id,
          email: invite.email,
          role: invite.role,
          inviteCode: invite.inviteCode,
          status: invite.status,
          expiresAt: invite.expiresAt,
        },
      },
      { status: 201 }
    );
  } catch (err) {
    return handleApiError(err);
  }
}

const updateMemberSchema = z.object({
  memberId: z.number().int().positive(),
  role: roleEnum.optional(),
  status: z.enum(["active", "suspended"]).optional(),
});

export async function PATCH(request: Request) {
  try {
    const ctx = await requireAuth(request, "workspace:users");
    const body = updateMemberSchema.parse(await request.json());

    const [member] = await db
      .select()
      .from(workspaceMembers)
      .where(
        and(
          eq(workspaceMembers.id, body.memberId),
          eq(workspaceMembers.tenantId, ctx.tenantId)
        )
      )
      .limit(1);

    if (!member) {
      throw new ApiError(404, "Workspace member not found.");
    }

    if (member.role === "owner" && ctx.role !== "owner") {
      throw new ApiError(403, "Cannot modify a workspace Owner.");
    }
    if (member.userId === ctx.user.id && body.status === "suspended") {
      throw new ApiError(400, "You cannot suspend your own account.");
    }

    const updates: Partial<typeof workspaceMembers.$inferInsert> = {};
    if (body.role) updates.role = body.role;
    if (body.status) updates.status = body.status;

    const [updated] = await db
      .update(workspaceMembers)
      .set(updates)
      .where(
        and(
          eq(workspaceMembers.id, member.id),
          eq(workspaceMembers.tenantId, ctx.tenantId)
        )
      )
      .returning();

    await recordAuditLog({
      tenantId: ctx.tenantId,
      userId: ctx.user.id,
      actorName: ctx.user.fullName,
      action: "member.updated",
      module: "workspace",
      entityType: "workspace_member",
      entityId: member.id,
      summary: `Updated member #${member.id} (${body.role || member.role}, ${
        body.status || member.status
      })`,
      ipAddress: ctx.ipAddress,
    });

    return NextResponse.json({ member: updated });
  } catch (err) {
    return handleApiError(err);
  }
}

export async function DELETE(request: Request) {
  try {
    const ctx = await requireAuth(request, "workspace:users");
    const url = new URL(request.url);
    const invitationId = Number(url.searchParams.get("invitationId"));
    if (!Number.isInteger(invitationId) || invitationId <= 0) {
      throw new ApiError(400, "Valid invitationId query parameter required.");
    }

    await db
      .update(workspaceInvitations)
      .set({ status: "revoked" })
      .where(
        and(
          eq(workspaceInvitations.id, invitationId),
          eq(workspaceInvitations.tenantId, ctx.tenantId)
        )
      );

    return NextResponse.json({ ok: true });
  } catch (err) {
    return handleApiError(err);
  }
}
