import { NextResponse } from "next/server";
import { z } from "zod";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import {
  billingEvents,
  documents,
  tenants,
  workflows,
  workspaceMembers,
} from "@/db/schema";
import { handleApiError, requireAuth } from "@/lib/auth";
import { DEFAULT_PLANS } from "@/lib/permissions";
import { recordAuditLog } from "@/lib/audit";

const COMMERCIAL_ADDONS = [
  {
    id: "cloud_hosting",
    name: "Dedicated Cloud Region",
    priceLabel: "₹2,499/mo",
    description: "Isolated compute & automated point-in-time PostgreSQL recovery.",
  },
  {
    id: "ai_pack",
    name: "Advanced AI Token Pack (+5M)",
    priceLabel: "₹799/mo",
    description: "High-volume executive reports, anomaly monitoring & receipt OCR.",
  },
  {
    id: "data_migration",
    name: "Assisted Data Migration & Onboarding",
    priceLabel: "₹4,999 one-time",
    description: "Import legacy Tally, Zoho, CSV spreadsheets & chart of accounts.",
  },
  {
    id: "custom_workflows",
    name: "Custom Workflows & API Integrations",
    priceLabel: "Custom quote",
    description: "Bespoke ERP integrations, webhooks, and dedicated support engineer.",
  },
];

export async function GET(request: Request) {
  try {
    const ctx = await requireAuth(request);
    const tId = ctx.tenantId;

    const [members, wfs, docs, events] = await Promise.all([
      db
        .select({ id: workspaceMembers.id })
        .from(workspaceMembers)
        .where(eq(workspaceMembers.tenantId, tId)),
      db.select({ id: workflows.id }).from(workflows).where(eq(workflows.tenantId, tId)),
      db
        .select({ sizeBytes: documents.sizeBytes })
        .from(documents)
        .where(eq(documents.tenantId, tId)),
      db
        .select()
        .from(billingEvents)
        .where(eq(billingEvents.tenantId, tId))
        .orderBy(desc(billingEvents.createdAt))
        .limit(20),
    ]);

    const overrides = ctx.tenant.planConfig || {};
    const plans = DEFAULT_PLANS.map((p) => {
      const ov = overrides[p.id];
      if (!ov) return p;
      return {
        ...p,
        priceInr: ov.priceInr,
        priceDisplay: `₹${ov.priceInr.toLocaleString("en-IN")}`,
        aiTokenLimit: ov.aiTokenLimit || p.aiTokenLimit,
        maxUsers: ov.maxUsers || p.maxUsers,
      };
    });

    const activePlan = plans.find((p) => p.id === ctx.tenant.plan) || plans[0];

    return NextResponse.json({
      currentPlan: ctx.tenant.plan,
      billingStatus: ctx.tenant.billingStatus,
      canManageBilling: ctx.permissions.has("workspace:billing"),
      plans,
      addons: COMMERCIAL_ADDONS,
      usage: {
        seatsUsed: members.length,
        seatsLimit: activePlan.maxUsers,
        workflowsUsed: wfs.length,
        workflowsLimit: activePlan.maxWorkflows,
        aiTokensUsed: ctx.tenant.aiTokensUsed,
        aiTokensLimit: ctx.tenant.aiTokenLimit,
        storageBytesUsed: docs.reduce((s, d) => s + d.sizeBytes, 0),
        apiCallsCount: ctx.tenant.apiCallsCount,
      },
      history: events,
    });
  } catch (err) {
    return handleApiError(err);
  }
}

const billingActionSchema = z.discriminatedUnion("action", [
  z.object({
    action: z.literal("change_plan"),
    plan: z.enum(["community", "starter", "pro", "business", "custom"]),
    customNote: z.string().max(300).optional(),
  }),
  z.object({
    action: z.literal("configure_pricing"),
    planId: z.enum(["starter", "pro", "business"]),
    priceInr: z.number().int().min(0).max(500000),
  }),
]);

export async function POST(request: Request) {
  try {
    const ctx = await requireAuth(request, "workspace:billing");
    const body = billingActionSchema.parse(await request.json());
    const tId = ctx.tenantId;

    if (body.action === "configure_pricing") {
      const base = DEFAULT_PLANS.find((p) => p.id === body.planId)!;
      const nextConfig = {
        ...(ctx.tenant.planConfig || {}),
        [body.planId]: {
          priceInr: body.priceInr,
          label: base.name,
          period: base.period,
          aiTokenLimit: base.aiTokenLimit,
          maxUsers: base.maxUsers,
        },
      };
      await db
        .update(tenants)
        .set({ planConfig: nextConfig, updatedAt: new Date() })
        .where(eq(tenants.id, tId));

      return NextResponse.json({ ok: true, planConfig: nextConfig });
    }

    const planDef =
      DEFAULT_PLANS.find((p) => p.id === body.plan) || DEFAULT_PLANS[0];
    const override = ctx.tenant.planConfig?.[body.plan];
    const amountInr = override?.priceInr ?? planDef.priceInr ?? 0;

    await db
      .update(tenants)
      .set({
        plan: body.plan,
        billingStatus: body.plan === "custom" ? "enterprise_review" : "active",
        aiTokenLimit: planDef.aiTokenLimit,
        updatedAt: new Date(),
      })
      .where(eq(tenants.id, tId));

    const description =
      body.plan === "custom"
        ? `Requested Custom Enterprise plan${
            body.customNote ? ` (${body.customNote})` : ""
          }`
        : `Switched subscription from ${ctx.tenant.plan} to ${planDef.name} (₹${amountInr.toLocaleString(
            "en-IN"
          )})`;

    const [event] = await db
      .insert(billingEvents)
      .values({
        tenantId: tId,
        previousPlan: ctx.tenant.plan,
        newPlan: body.plan,
        amountInr,
        description,
        actorName: ctx.user.fullName,
      })
      .returning();

    await recordAuditLog({
      tenantId: tId,
      userId: ctx.user.id,
      actorName: ctx.user.fullName,
      action: "billing.plan_changed",
      module: "billing",
      entityType: "tenant",
      entityId: tId,
      summary: description,
      ipAddress: ctx.ipAddress,
    });

    return NextResponse.json({ ok: true, plan: body.plan, event });
  } catch (err) {
    return handleApiError(err);
  }
}
