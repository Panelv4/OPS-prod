import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { sessions } from "@/db/schema";
import { clearSessionCookie, getAuthContext } from "@/lib/auth";
import { recordAuditLog } from "@/lib/audit";

export async function POST(request: Request) {
  const ctx = await getAuthContext(request);
  if (ctx) {
    await db.delete(sessions).where(eq(sessions.id, ctx.sessionId));
    await recordAuditLog({
      tenantId: ctx.tenantId,
      userId: ctx.user.id,
      actorName: ctx.user.fullName,
      action: "auth.logout",
      module: "auth",
      entityType: "session",
      summary: `${ctx.user.fullName} signed out`,
      ipAddress: ctx.ipAddress,
    });
  }
  const response = NextResponse.json({ ok: true });
  clearSessionCookie(response, request);
  return response;
}
