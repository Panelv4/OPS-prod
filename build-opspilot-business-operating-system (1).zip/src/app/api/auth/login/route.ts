import { NextResponse } from "next/server";
import { z } from "zod";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { tenants, users, workspaceMembers } from "@/db/schema";
import { checkRateLimit, getClientIp, verifyPassword } from "@/lib/security";
import {
  attachSessionCookie,
  createSession,
  handleApiError,
} from "@/lib/auth";
import { recordAuditLog } from "@/lib/audit";
import { ensureDatabaseReady } from "@/db/bootstrap";

const loginSchema = z.object({
  email: z.string().email().optional(),
  password: z.string().min(1).optional(),
  demoRole: z
    .enum(["owner", "hr_manager", "salesperson", "accountant", "employee", "tenant2"])
    .optional(),
});

const DEMO_EMAILS: Record<string, string> = {
  owner: "arjun@meridianstudio.in",
  hr_manager: "ananya@meridianstudio.in",
  salesperson: "rohan@meridianstudio.in",
  accountant: "kavya@meridianstudio.in",
  employee: "dev@meridianstudio.in",
  tenant2: "priya@northstarlabs.in",
};

export async function POST(request: Request) {
  try {
    const ip = getClientIp(request);
    const rl = checkRateLimit(`login:${ip}`, 20, 60_000);
    if (!rl.allowed) {
      return NextResponse.json(
        {
          error: `Too many sign-in attempts. Retry in ${rl.retryAfterSec} seconds.`,
        },
        { status: 429 }
      );
    }

    const body = loginSchema.parse(await request.json());

    let email = body.email?.trim().toLowerCase() || "";
    let isDemoQuickLogin = false;

    await ensureDatabaseReady();
    if (body.demoRole) {
      email = DEMO_EMAILS[body.demoRole] || DEMO_EMAILS.owner;
      isDemoQuickLogin = true;
    }

    if (!email) {
      return NextResponse.json({ error: "Email address is required." }, { status: 400 });
    }

    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.email, email))
      .limit(1);

    if (!user) {
      return NextResponse.json(
        { error: "Invalid email or password." },
        { status: 401 }
      );
    }

    if (!isDemoQuickLogin) {
      if (!body.password) {
        return NextResponse.json({ error: "Password is required." }, { status: 400 });
      }
      const valid = await verifyPassword(body.password, user.passwordHash);
      if (!valid) {
        return NextResponse.json(
          { error: "Invalid email or password." },
          { status: 401 }
        );
      }
    }

    const memberships = await db
      .select({
        tenantId: workspaceMembers.tenantId,
        role: workspaceMembers.role,
        tenantName: tenants.name,
      })
      .from(workspaceMembers)
      .innerJoin(tenants, eq(workspaceMembers.tenantId, tenants.id))
      .where(
        and(
          eq(workspaceMembers.userId, user.id),
          eq(workspaceMembers.status, "active")
        )
      );

    if (memberships.length === 0) {
      return NextResponse.json(
        { error: "Your account has no active workspace memberships." },
        { status: 403 }
      );
    }

    const primary = memberships[0];
    const session = await createSession({
      userId: user.id,
      tenantId: primary.tenantId,
      request,
    });

    await recordAuditLog({
      tenantId: primary.tenantId,
      userId: user.id,
      actorName: user.fullName,
      action: "auth.login",
      module: "auth",
      entityType: "session",
      summary: `${user.fullName} signed in to ${primary.tenantName}`,
      ipAddress: ip,
    });

    const response = NextResponse.json({
      user: {
        id: user.id,
        email: user.email,
        fullName: user.fullName,
        emailVerified: user.emailVerified,
      },
      tenantId: primary.tenantId,
      workspaceName: primary.tenantName,
      role: primary.role,
      csrfToken: session.csrfToken,
      sessionToken: session.rawToken,
    });

    attachSessionCookie(response, session.rawToken, session.expiresAt, request);
    return response;
  } catch (err) {
    return handleApiError(err);
  }
}
