import { NextResponse } from "next/server";
import { z } from "zod";
import { and, eq, gt } from "drizzle-orm";
import { db } from "@/db";
import { sessions, users } from "@/db/schema";
import {
  checkRateLimit,
  generateSecureToken,
  getClientIp,
  hashPassword,
  sha256,
  validatePasswordStrength,
} from "@/lib/security";
import { handleApiError } from "@/lib/auth";

const resetSchema = z.discriminatedUnion("step", [
  z.object({
    step: z.literal("request"),
    email: z.string().email(),
  }),
  z.object({
    step: z.literal("confirm"),
    token: z.string().min(10),
    newPassword: z.string().min(8).max(128),
  }),
]);

export async function POST(request: Request) {
  try {
    const ip = getClientIp(request);
    const rl = checkRateLimit(`pwd-reset:${ip}`, 10, 60_000);
    if (!rl.allowed) {
      return NextResponse.json(
        { error: "Too many recovery attempts. Please wait a minute." },
        { status: 429 }
      );
    }

    const body = resetSchema.parse(await request.json());

    if (body.step === "request") {
      const email = body.email.trim().toLowerCase();
      const [user] = await db
        .select()
        .from(users)
        .where(eq(users.email, email))
        .limit(1);

      let devResetToken: string | undefined;
      if (user) {
        const rawToken = generateSecureToken(24);
        const tokenHash = sha256(rawToken);
        const expiresAt = new Date(Date.now() + 30 * 60 * 1000); // 30 minutes
        await db
          .update(users)
          .set({
            resetTokenHash: tokenHash,
            resetTokenExpiresAt: expiresAt,
            updatedAt: new Date(),
          })
          .where(eq(users.id, user.id));

        if (!process.env.SMTP_HOST) {
          devResetToken = rawToken;
        }
      }

      return NextResponse.json({
        message:
          "If an account exists for that email, a password recovery token has been generated (valid for 30 minutes).",
        smtpConfigured: Boolean(process.env.SMTP_HOST),
        devResetToken,
      });
    }

    const pwdErr = validatePasswordStrength(body.newPassword);
    if (pwdErr) {
      return NextResponse.json({ error: pwdErr }, { status: 400 });
    }

    const tokenHash = sha256(body.token.trim());
    const [user] = await db
      .select()
      .from(users)
      .where(
        and(
          eq(users.resetTokenHash, tokenHash),
          gt(users.resetTokenExpiresAt, new Date())
        )
      )
      .limit(1);

    if (!user) {
      return NextResponse.json(
        { error: "Invalid or expired password recovery token." },
        { status: 400 }
      );
    }

    const passwordHash = await hashPassword(body.newPassword);
    await db
      .update(users)
      .set({
        passwordHash,
        resetTokenHash: null,
        resetTokenExpiresAt: null,
        updatedAt: new Date(),
      })
      .where(eq(users.id, user.id));

    // Invalidate all existing sessions on password reset
    await db.delete(sessions).where(eq(sessions.userId, user.id));

    return NextResponse.json({
      message: "Password successfully reset. You can now sign in with your new password.",
    });
  } catch (err) {
    return handleApiError(err);
  }
}
