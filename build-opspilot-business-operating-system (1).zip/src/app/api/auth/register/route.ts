import { NextResponse } from "next/server";
import { z } from "zod";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import {
  tenants,
  users,
  workspaceInvitations,
  workspaceMembers,
} from "@/db/schema";
import {
  checkRateLimit,
  generateSecureToken,
  getClientIp,
  hashPassword,
  sanitizeText,
  sha256,
  validatePasswordStrength,
} from "@/lib/security";
import {
  DEFAULT_DASHBOARD_WIDGETS,
  DEFAULT_ROLE_PERMISSIONS,
} from "@/lib/permissions";
import {
  attachSessionCookie,
  createSession,
  handleApiError,
} from "@/lib/auth";
import { createNotification, recordAuditLog } from "@/lib/audit";
import { ensureDatabaseReady } from "@/db/bootstrap";

const registerSchema = z.object({
  fullName: z.string().min(2).max(100),
  email: z.string().email().max(150),
  password: z.string().min(8).max(128),
  workspaceName: z.string().min(2).max(120).optional(),
  industry: z.string().max(100).optional(),
  currency: z.enum(["INR", "USD", "EUR", "GBP", "SGD", "AED"]).optional(),
  jurisdiction: z.enum(["IN", "US", "GB", "SG", "AE"]).optional(),
  inviteCode: z.string().max(120).optional(),
});

function slugify(name: string): string {
  const base = name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 36);
  const suffix = generateSecureToken(3);
  return `${base || "workspace"}-${suffix}`;
}

export async function POST(request: Request) {
  try {
    const ip = getClientIp(request);
    const rl = checkRateLimit(`register:${ip}`, 15, 60_000);
    if (!rl.allowed) {
      return NextResponse.json(
        { error: "Too many registration attempts. Please try again shortly." },
        { status: 429 }
      );
    }

    await ensureDatabaseReady();
    const body = registerSchema.parse(await request.json());
    const email = body.email.trim().toLowerCase();
    const pwdError = validatePasswordStrength(body.password);
    if (pwdError) {
      return NextResponse.json({ error: pwdError }, { status: 400 });
    }

    const existing = await db
      .select({ id: users.id })
      .from(users)
      .where(eq(users.email, email))
      .limit(1);
    if (existing.length > 0) {
      return NextResponse.json(
        { error: "An account with this email address already exists." },
        { status: 409 }
      );
    }

    const passwordHash = await hashPassword(body.password);
    const rawVerifyToken = generateSecureToken(20);
    const verificationTokenHash = sha256(rawVerifyToken);

    const [user] = await db
      .insert(users)
      .values({
        email,
        passwordHash,
        fullName: sanitizeText(body.fullName),
        emailVerified: false,
        verificationTokenHash,
      })
      .returning();

    let targetTenantId: number;
    let assignedRole: typeof workspaceMembers.$inferSelect.role = "owner";
    let workspaceNameCreated = "";

    // Check optional workspace invitation code
    if (body.inviteCode?.trim()) {
      const [invite] = await db
        .select()
        .from(workspaceInvitations)
        .where(eq(workspaceInvitations.inviteCode, body.inviteCode.trim()))
        .limit(1);

      if (!invite || invite.status !== "pending" || invite.expiresAt < new Date()) {
        return NextResponse.json(
          { error: "Workspace invitation code is invalid or expired." },
          { status: 400 }
        );
      }

      targetTenantId = invite.tenantId;
      assignedRole = invite.role;

      await db.insert(workspaceMembers).values({
        tenantId: invite.tenantId,
        userId: user.id,
        role: invite.role,
        title: invite.role.replace("_", " "),
      });

      await db
        .update(workspaceInvitations)
        .set({ status: "accepted" })
        .where(eq(workspaceInvitations.id, invite.id));

      const [tRow] = await db
        .select()
        .from(tenants)
        .where(eq(tenants.id, invite.tenantId))
        .limit(1);
      workspaceNameCreated = tRow?.name || "Workspace";
    } else {
      const wsName = sanitizeText(
        body.workspaceName || `${body.fullName.split(" ")[0]}'s Workspace`
      );
      const currency = body.currency || "INR";
      const jurisdiction = body.jurisdiction || "IN";
      const taxLabel =
        jurisdiction === "IN" || jurisdiction === "SG"
          ? "GST"
          : jurisdiction === "GB"
          ? "VAT"
          : "Tax";

      const [tenant] = await db
        .insert(tenants)
        .values({
          name: wsName,
          slug: slugify(wsName),
          industry: sanitizeText(body.industry || "Technology & Services"),
          currency,
          jurisdiction,
          taxLabel,
          defaultTaxBps: jurisdiction === "AE" ? 500 : 1800,
          plan: "community",
          billingStatus: "active",
          aiProvider: "deterministic",
          aiModel: "opspilot-core-v1",
          aiTokenLimit: 50000,
          dashboardWidgets: DEFAULT_DASHBOARD_WIDGETS,
          rolePermissions: DEFAULT_ROLE_PERMISSIONS,
        })
        .returning();

      targetTenantId = tenant.id;
      workspaceNameCreated = tenant.name;

      await db.insert(workspaceMembers).values({
        tenantId: tenant.id,
        userId: user.id,
        role: "owner",
        title: "Workspace Owner",
      });

      await createNotification({
        tenantId: tenant.id,
        userId: user.id,
        title: `Welcome to ${tenant.name}`,
        message:
          "Your isolated OpsPilot workspace is ready. Start by adding customers, products, or inviting your team.",
        type: "success",
        link: "/app/settings",
      });
    }

    await recordAuditLog({
      tenantId: targetTenantId,
      userId: user.id,
      actorName: user.fullName,
      action: "auth.registered",
      module: "auth",
      entityType: "user",
      entityId: user.id,
      summary: `${user.fullName} registered and joined ${workspaceNameCreated} as ${assignedRole}`,
      ipAddress: ip,
    });

    const session = await createSession({
      userId: user.id,
      tenantId: targetTenantId,
      request,
    });

    const response = NextResponse.json(
      {
        user: {
          id: user.id,
          email: user.email,
          fullName: user.fullName,
          emailVerified: user.emailVerified,
        },
        tenantId: targetTenantId,
        workspaceName: workspaceNameCreated,
        role: assignedRole,
        csrfToken: session.csrfToken,
        sessionToken: session.rawToken,
        emailVerificationPending: true,
        verificationTokenPreview: process.env.SMTP_HOST ? undefined : rawVerifyToken,
      },
      { status: 201 }
    );
    attachSessionCookie(response, session.rawToken, session.expiresAt, request);
    return response;
  } catch (err) {
    return handleApiError(err);
  }
}
