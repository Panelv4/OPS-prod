import {
  pgTable,
  serial,
  integer,
  bigint,
  text,
  boolean,
  timestamp,
  jsonb,
  index,
  uniqueIndex,
} from "drizzle-orm/pg-core";

// ============================================================================
// 1. IDENTITY, AUTHENTICATION & MULTI-TENANT WORKSPACES
// ============================================================================

export interface NotificationPrefs {
  inApp: boolean;
  email: boolean;
  invoiceAlerts: boolean;
  leadAlerts: boolean;
  stockAlerts: boolean;
  hrAlerts: boolean;
  taskAlerts: boolean;
  automationAlerts: boolean;
}

export interface DashboardWidgetConfig {
  id: string;
  label: string;
  visible: boolean;
  order: number;
}

export type WorkspaceRole =
  | "owner"
  | "administrator"
  | "manager"
  | "hr_manager"
  | "accountant"
  | "salesperson"
  | "employee";

export type PlanTier = "community" | "starter" | "pro" | "business" | "custom";

export const users = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    email: text("email").notNull(),
    passwordHash: text("password_hash").notNull(),
    fullName: text("full_name").notNull(),
    phone: text("phone"),
    avatarUrl: text("avatar_url"),
    emailVerified: boolean("email_verified").notNull().default(false),
    verificationTokenHash: text("verification_token_hash"),
    resetTokenHash: text("reset_token_hash"),
    resetTokenExpiresAt: timestamp("reset_token_expires_at"),
    notificationPrefs: jsonb("notification_prefs")
      .$type<NotificationPrefs>()
      .notNull()
      .default({
        inApp: true,
        email: false,
        invoiceAlerts: true,
        leadAlerts: true,
        stockAlerts: true,
        hrAlerts: true,
        taskAlerts: true,
        automationAlerts: true,
      }),
    lastLoginAt: timestamp("last_login_at"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => [uniqueIndex("users_email_idx").on(t.email)]
);

export const tenants = pgTable(
  "tenants",
  {
    id: serial("id").primaryKey(),
    name: text("name").notNull(),
    slug: text("slug").notNull(),
    industry: text("industry").notNull().default("Technology & Services"),
    currency: text("currency").notNull().default("INR"),
    jurisdiction: text("jurisdiction").notNull().default("IN"),
    taxLabel: text("tax_label").notNull().default("GST"),
    defaultTaxBps: integer("default_tax_bps").notNull().default(1800),
    taxId: text("tax_id"),
    address: text("address"),
    website: text("website"),
    plan: text("plan").$type<PlanTier>().notNull().default("community"),
    billingStatus: text("billing_status").notNull().default("active"),
    customPriceInr: integer("custom_price_inr"),
    planConfig: jsonb("plan_config")
      .$type<Record<string, { priceInr: number; label: string; period: string; aiTokenLimit: number; maxUsers: number }>>()
      .notNull()
      .default({}),
    aiProvider: text("ai_provider").notNull().default("deterministic"),
    aiModel: text("ai_model").notNull().default("opspilot-core-v1"),
    aiApiKeyEncrypted: text("ai_api_key_encrypted"),
    aiTokensUsed: integer("ai_tokens_used").notNull().default(0),
    aiTokenLimit: integer("ai_token_limit").notNull().default(250000),
    storageBytesUsed: bigint("storage_bytes_used", { mode: "number" }).notNull().default(0),
    apiCallsCount: integer("api_calls_count").notNull().default(0),
    dashboardWidgets: jsonb("dashboard_widgets")
      .$type<DashboardWidgetConfig[]>()
      .notNull()
      .default([]),
    rolePermissions: jsonb("role_permissions")
      .$type<Record<string, string[]>>()
      .notNull()
      .default({}),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => [uniqueIndex("tenants_slug_idx").on(t.slug)]
);

export const workspaceMembers = pgTable(
  "workspace_members",
  {
    id: serial("id").primaryKey(),
    tenantId: integer("tenant_id")
      .notNull()
      .references(() => tenants.id, { onDelete: "cascade" }),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    role: text("role").$type<WorkspaceRole>().notNull().default("employee"),
    title: text("title"),
    customPermissions: jsonb("custom_permissions").$type<string[] | null>().default(null),
    status: text("status").notNull().default("active"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("workspace_members_tenant_user_idx").on(t.tenantId, t.userId),
    index("workspace_members_user_idx").on(t.userId),
  ]
);

export const workspaceInvitations = pgTable(
  "workspace_invitations",
  {
    id: serial("id").primaryKey(),
    tenantId: integer("tenant_id")
      .notNull()
      .references(() => tenants.id, { onDelete: "cascade" }),
    email: text("email").notNull(),
    role: text("role").$type<WorkspaceRole>().notNull().default("employee"),
    tokenHash: text("token_hash").notNull(),
    inviteCode: text("invite_code").notNull(),
    invitedByUserId: integer("invited_by_user_id").references(() => users.id, {
      onDelete: "set null",
    }),
    status: text("status").notNull().default("pending"),
    expiresAt: timestamp("expires_at").notNull(),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [
    index("workspace_invitations_tenant_idx").on(t.tenantId),
    uniqueIndex("workspace_invitations_token_idx").on(t.tokenHash),
  ]
);

export const sessions = pgTable(
  "sessions",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    activeTenantId: integer("active_tenant_id")
      .notNull()
      .references(() => tenants.id, { onDelete: "cascade" }),
    tokenHash: text("token_hash").notNull(),
    csrfToken: text("csrf_token").notNull(),
    ipAddress: text("ip_address"),
    userAgent: text("user_agent"),
    expiresAt: timestamp("expires_at").notNull(),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("sessions_token_idx").on(t.tokenHash),
    index("sessions_user_idx").on(t.userId),
  ]
);

export const auditLogs = pgTable(
  "audit_logs",
  {
    id: serial("id").primaryKey(),
    tenantId: integer("tenant_id")
      .notNull()
      .references(() => tenants.id, { onDelete: "cascade" }),
    userId: integer("user_id").references(() => users.id, { onDelete: "set null" }),
    actorName: text("actor_name").notNull(),
    action: text("action").notNull(),
    module: text("module").notNull(),
    entityType: text("entity_type").notNull(),
    entityId: text("entity_id"),
    summary: text("summary").notNull(),
    metadata: jsonb("metadata").$type<Record<string, unknown>>().default({}),
    ipAddress: text("ip_address"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [
    index("audit_logs_tenant_idx").on(t.tenantId),
    index("audit_logs_created_idx").on(t.tenantId, t.createdAt),
  ]
);

// ============================================================================
// 2. CRM MODULE (CUSTOMERS, COMMUNICATIONS, LEADS & PIPELINE)
// ============================================================================

export const customers = pgTable(
  "customers",
  {
    id: serial("id").primaryKey(),
    tenantId: integer("tenant_id")
      .notNull()
      .references(() => tenants.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    company: text("company").notNull(),
    email: text("email").notNull(),
    phone: text("phone"),
    address: text("address"),
    customerType: text("customer_type").notNull().default("business"),
    tags: jsonb("tags").$type<string[]>().notNull().default([]),
    notes: text("notes"),
    assignedUserId: integer("assigned_user_id").references(() => users.id, {
      onDelete: "set null",
    }),
    assignedName: text("assigned_name"),
    totalSpentCents: bigint("total_spent_cents", { mode: "number" }).notNull().default(0),
    status: text("status").notNull().default("active"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => [
    index("customers_tenant_idx").on(t.tenantId),
    index("customers_email_idx").on(t.tenantId, t.email),
  ]
);

export const customerCommunications = pgTable(
  "customer_communications",
  {
    id: serial("id").primaryKey(),
    tenantId: integer("tenant_id")
      .notNull()
      .references(() => tenants.id, { onDelete: "cascade" }),
    customerId: integer("customer_id")
      .notNull()
      .references(() => customers.id, { onDelete: "cascade" }),
    userId: integer("user_id").references(() => users.id, { onDelete: "set null" }),
    authorName: text("author_name").notNull(),
    channel: text("channel").notNull().default("note"),
    subject: text("subject").notNull(),
    content: text("content").notNull(),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [
    index("customer_comms_tenant_idx").on(t.tenantId),
    index("customer_comms_customer_idx").on(t.tenantId, t.customerId),
  ]
);

export const leads = pgTable(
  "leads",
  {
    id: serial("id").primaryKey(),
    tenantId: integer("tenant_id")
      .notNull()
      .references(() => tenants.id, { onDelete: "cascade" }),
    customerId: integer("customer_id").references(() => customers.id, {
      onDelete: "set null",
    }),
    title: text("title").notNull(),
    contactName: text("contact_name").notNull(),
    company: text("company").notNull(),
    email: text("email"),
    phone: text("phone"),
    source: text("source").notNull().default("Website"),
    estimatedValueCents: bigint("estimated_value_cents", { mode: "number" })
      .notNull()
      .default(0),
    priority: text("priority").notNull().default("medium"),
    stage: text("stage").notNull().default("new"),
    assignedUserId: integer("assigned_user_id").references(() => users.id, {
      onDelete: "set null",
    }),
    assignedName: text("assigned_name"),
    followUpDate: text("follow_up_date"),
    notes: text("notes"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => [
    index("leads_tenant_idx").on(t.tenantId),
    index("leads_stage_idx").on(t.tenantId, t.stage),
  ]
);

// ============================================================================
// 3. VENDORS, INVENTORY & PROCUREMENT
// ============================================================================

export const vendors = pgTable(
  "vendors",
  {
    id: serial("id").primaryKey(),
    tenantId: integer("tenant_id")
      .notNull()
      .references(() => tenants.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    contactName: text("contact_name").notNull(),
    email: text("email").notNull(),
    phone: text("phone"),
    address: text("address"),
    category: text("category").notNull().default("General Supplier"),
    taxId: text("tax_id"),
    paymentTerms: text("payment_terms").notNull().default("Net 30"),
    rating: integer("rating").notNull().default(5),
    notes: text("notes"),
    status: text("status").notNull().default("active"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => [index("vendors_tenant_idx").on(t.tenantId)]
);

export const products = pgTable(
  "products",
  {
    id: serial("id").primaryKey(),
    tenantId: integer("tenant_id")
      .notNull()
      .references(() => tenants.id, { onDelete: "cascade" }),
    vendorId: integer("vendor_id").references(() => vendors.id, { onDelete: "set null" }),
    sku: text("sku").notNull(),
    name: text("name").notNull(),
    category: text("category").notNull().default("General"),
    itemType: text("item_type").notNull().default("product"),
    description: text("description"),
    imageUrl: text("image_url"),
    unit: text("unit").notNull().default("unit"),
    purchasePriceCents: bigint("purchase_price_cents", { mode: "number" })
      .notNull()
      .default(0),
    sellingPriceCents: bigint("selling_price_cents", { mode: "number" })
      .notNull()
      .default(0),
    taxRateBps: integer("tax_rate_bps").notNull().default(1800),
    stockQuantity: integer("stock_quantity").notNull().default(0),
    reorderLevel: integer("reorder_level").notNull().default(10),
    status: text("status").notNull().default("active"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => [
    index("products_tenant_idx").on(t.tenantId),
    uniqueIndex("products_tenant_sku_idx").on(t.tenantId, t.sku),
  ]
);

export const stockMovements = pgTable(
  "stock_movements",
  {
    id: serial("id").primaryKey(),
    tenantId: integer("tenant_id")
      .notNull()
      .references(() => tenants.id, { onDelete: "cascade" }),
    productId: integer("product_id")
      .notNull()
      .references(() => products.id, { onDelete: "cascade" }),
    movementType: text("movement_type").notNull(),
    quantityDelta: integer("quantity_delta").notNull(),
    previousStock: integer("previous_stock").notNull(),
    newStock: integer("new_stock").notNull(),
    referenceType: text("reference_type"),
    referenceId: text("reference_id"),
    reason: text("reason").notNull(),
    actorName: text("actor_name").notNull(),
    createdByUserId: integer("created_by_user_id").references(() => users.id, {
      onDelete: "set null",
    }),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [
    index("stock_movements_tenant_idx").on(t.tenantId),
    index("stock_movements_product_idx").on(t.tenantId, t.productId),
  ]
);

export const purchaseOrders = pgTable(
  "purchase_orders",
  {
    id: serial("id").primaryKey(),
    tenantId: integer("tenant_id")
      .notNull()
      .references(() => tenants.id, { onDelete: "cascade" }),
    vendorId: integer("vendor_id")
      .notNull()
      .references(() => vendors.id, { onDelete: "restrict" }),
    poNumber: text("po_number").notNull(),
    status: text("status").notNull().default("pending_approval"),
    orderDate: text("order_date").notNull(),
    expectedDate: text("expected_date"),
    receivedDate: text("received_date"),
    vendorInvoiceNumber: text("vendor_invoice_number"),
    subtotalCents: bigint("subtotal_cents", { mode: "number" }).notNull().default(0),
    taxCents: bigint("tax_cents", { mode: "number" }).notNull().default(0),
    totalCents: bigint("total_cents", { mode: "number" }).notNull().default(0),
    paidCents: bigint("paid_cents", { mode: "number" }).notNull().default(0),
    balanceCents: bigint("balance_cents", { mode: "number" }).notNull().default(0),
    notes: text("notes"),
    approvedByName: text("approved_by_name"),
    createdByUserId: integer("created_by_user_id").references(() => users.id, {
      onDelete: "set null",
    }),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => [
    index("purchase_orders_tenant_idx").on(t.tenantId),
    uniqueIndex("purchase_orders_number_idx").on(t.tenantId, t.poNumber),
  ]
);

export const purchaseOrderItems = pgTable(
  "purchase_order_items",
  {
    id: serial("id").primaryKey(),
    tenantId: integer("tenant_id")
      .notNull()
      .references(() => tenants.id, { onDelete: "cascade" }),
    purchaseOrderId: integer("purchase_order_id")
      .notNull()
      .references(() => purchaseOrders.id, { onDelete: "cascade" }),
    productId: integer("product_id").references(() => products.id, {
      onDelete: "set null",
    }),
    description: text("description").notNull(),
    quantity: integer("quantity").notNull(),
    receivedQuantity: integer("received_quantity").notNull().default(0),
    unitCostCents: bigint("unit_cost_cents", { mode: "number" }).notNull(),
    taxRateBps: integer("tax_rate_bps").notNull().default(1800),
    lineTotalCents: bigint("line_total_cents", { mode: "number" }).notNull(),
  },
  (t) => [index("po_items_po_idx").on(t.tenantId, t.purchaseOrderId)]
);

// ============================================================================
// 4. SALES, QUOTATIONS, ORDERS & INVOICING
// ============================================================================

export const invoices = pgTable(
  "invoices",
  {
    id: serial("id").primaryKey(),
    tenantId: integer("tenant_id")
      .notNull()
      .references(() => tenants.id, { onDelete: "cascade" }),
    customerId: integer("customer_id")
      .notNull()
      .references(() => customers.id, { onDelete: "restrict" }),
    docType: text("doc_type").notNull().default("invoice"), // quotation | sales_order | invoice
    invoiceNumber: text("invoice_number").notNull(),
    status: text("status").notNull().default("sent"), // draft | sent | approved | partial | paid | overdue | refunded | cancelled
    issueDate: text("issue_date").notNull(),
    dueDate: text("due_date").notNull(),
    subtotalCents: bigint("subtotal_cents", { mode: "number" }).notNull().default(0),
    discountCents: bigint("discount_cents", { mode: "number" }).notNull().default(0),
    taxCents: bigint("tax_cents", { mode: "number" }).notNull().default(0),
    totalCents: bigint("total_cents", { mode: "number" }).notNull().default(0),
    paidCents: bigint("paid_cents", { mode: "number" }).notNull().default(0),
    refundedCents: bigint("refunded_cents", { mode: "number" }).notNull().default(0),
    balanceCents: bigint("balance_cents", { mode: "number" }).notNull().default(0),
    currency: text("currency").notNull().default("INR"),
    notes: text("notes"),
    reminderCount: integer("reminder_count").notNull().default(0),
    lastReminderAt: timestamp("last_reminder_at"),
    createdByUserId: integer("created_by_user_id").references(() => users.id, {
      onDelete: "set null",
    }),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => [
    index("invoices_tenant_idx").on(t.tenantId),
    uniqueIndex("invoices_number_idx").on(t.tenantId, t.invoiceNumber),
  ]
);

export const invoiceItems = pgTable(
  "invoice_items",
  {
    id: serial("id").primaryKey(),
    tenantId: integer("tenant_id")
      .notNull()
      .references(() => tenants.id, { onDelete: "cascade" }),
    invoiceId: integer("invoice_id")
      .notNull()
      .references(() => invoices.id, { onDelete: "cascade" }),
    productId: integer("product_id").references(() => products.id, {
      onDelete: "set null",
    }),
    description: text("description").notNull(),
    quantity: integer("quantity").notNull(),
    unitPriceCents: bigint("unit_price_cents", { mode: "number" }).notNull(),
    discountCents: bigint("discount_cents", { mode: "number" }).notNull().default(0),
    taxRateBps: integer("tax_rate_bps").notNull().default(1800),
    taxAmountCents: bigint("tax_amount_cents", { mode: "number" }).notNull().default(0),
    lineTotalCents: bigint("line_total_cents", { mode: "number" }).notNull(),
  },
  (t) => [index("invoice_items_invoice_idx").on(t.tenantId, t.invoiceId)]
);

// ============================================================================
// 5. DOCUMENTS MANAGEMENT
// ============================================================================

export const documents = pgTable(
  "documents",
  {
    id: serial("id").primaryKey(),
    tenantId: integer("tenant_id")
      .notNull()
      .references(() => tenants.id, { onDelete: "cascade" }),
    title: text("title").notNull(),
    fileName: text("file_name").notNull(),
    mimeType: text("mime_type").notNull(),
    sizeBytes: integer("size_bytes").notNull(),
    category: text("category").notNull().default("general"),
    visibility: text("visibility").notNull().default("workspace"), // workspace | managers | hr_only | finance_only
    currentVersion: integer("current_version").notNull().default(1),
    contentBase64: text("content_base64"),
    textPreview: text("text_preview"),
    expiresAt: text("expires_at"),
    uploadedByUserId: integer("uploaded_by_user_id").references(() => users.id, {
      onDelete: "set null",
    }),
    uploaderName: text("uploader_name").notNull(),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => [index("documents_tenant_idx").on(t.tenantId)]
);

export const documentVersions = pgTable(
  "document_versions",
  {
    id: serial("id").primaryKey(),
    tenantId: integer("tenant_id")
      .notNull()
      .references(() => tenants.id, { onDelete: "cascade" }),
    documentId: integer("document_id")
      .notNull()
      .references(() => documents.id, { onDelete: "cascade" }),
    versionNumber: integer("version_number").notNull(),
    fileName: text("file_name").notNull(),
    mimeType: text("mime_type").notNull(),
    sizeBytes: integer("size_bytes").notNull(),
    contentBase64: text("content_base64"),
    changeNote: text("change_note").notNull(),
    uploaderName: text("uploader_name").notNull(),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("doc_versions_doc_idx").on(t.tenantId, t.documentId)]
);

// ============================================================================
// 6. FINANCE & IMMUTABLE LEDGER
// ============================================================================

export const transactions = pgTable(
  "transactions",
  {
    id: serial("id").primaryKey(),
    tenantId: integer("tenant_id")
      .notNull()
      .references(() => tenants.id, { onDelete: "cascade" }),
    entryNumber: text("entry_number").notNull(),
    type: text("type").notNull(), // income | expense | refund | vendor_payment | payroll | reversal
    direction: text("direction").notNull(), // credit (inflow) | debit (outflow)
    category: text("category").notNull(),
    amountCents: bigint("amount_cents", { mode: "number" }).notNull(),
    paymentMethod: text("payment_method").notNull().default("Bank Transfer"),
    transactionDate: text("transaction_date").notNull(),
    description: text("description").notNull(),
    customerId: integer("customer_id").references(() => customers.id, {
      onDelete: "set null",
    }),
    vendorId: integer("vendor_id").references(() => vendors.id, {
      onDelete: "set null",
    }),
    invoiceId: integer("invoice_id").references(() => invoices.id, {
      onDelete: "set null",
    }),
    purchaseOrderId: integer("purchase_order_id").references(() => purchaseOrders.id, {
      onDelete: "set null",
    }),
    receiptDocumentId: integer("receipt_document_id").references(() => documents.id, {
      onDelete: "set null",
    }),
    status: text("status").notNull().default("posted"), // posted | reversed
    reversalOfId: integer("reversal_of_id"),
    actorName: text("actor_name").notNull(),
    createdByUserId: integer("created_by_user_id").references(() => users.id, {
      onDelete: "set null",
    }),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [
    index("transactions_tenant_idx").on(t.tenantId),
    index("transactions_date_idx").on(t.tenantId, t.transactionDate),
  ]
);

// ============================================================================
// 7. HRMS (EMPLOYEES, ATTENDANCE, LEAVE, JURISDICTION-AWARE PAYROLL)
// ============================================================================

export const employees = pgTable(
  "employees",
  {
    id: serial("id").primaryKey(),
    tenantId: integer("tenant_id")
      .notNull()
      .references(() => tenants.id, { onDelete: "cascade" }),
    userId: integer("user_id").references(() => users.id, { onDelete: "set null" }),
    employeeCode: text("employee_code").notNull(),
    fullName: text("full_name").notNull(),
    email: text("email").notNull(),
    phone: text("phone"),
    department: text("department").notNull(),
    designation: text("designation").notNull(),
    joiningDate: text("joining_date").notNull(),
    employmentStatus: text("employment_status").notNull().default("active"),
    managerName: text("manager_name"),
    jurisdiction: text("jurisdiction").notNull().default("IN"),
    baseSalaryCents: bigint("base_salary_cents", { mode: "number" }).notNull().default(0),
    allowancesCents: bigint("allowances_cents", { mode: "number" }).notNull().default(0),
    deductionsCents: bigint("deductions_cents", { mode: "number" }).notNull().default(0),
    taxRateBps: integer("tax_rate_bps").notNull().default(1000),
    leaveBalanceAnnual: integer("leave_balance_annual").notNull().default(18),
    leaveBalanceSick: integer("leave_balance_sick").notNull().default(10),
    confidentialNotes: text("confidential_notes"),
    documentId: integer("document_id").references(() => documents.id, {
      onDelete: "set null",
    }),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => [
    index("employees_tenant_idx").on(t.tenantId),
    uniqueIndex("employees_code_idx").on(t.tenantId, t.employeeCode),
  ]
);

export const attendanceRecords = pgTable(
  "attendance_records",
  {
    id: serial("id").primaryKey(),
    tenantId: integer("tenant_id")
      .notNull()
      .references(() => tenants.id, { onDelete: "cascade" }),
    employeeId: integer("employee_id")
      .notNull()
      .references(() => employees.id, { onDelete: "cascade" }),
    date: text("date").notNull(),
    checkInTime: text("check_in_time"),
    checkOutTime: text("check_out_time"),
    status: text("status").notNull().default("present"), // present | late | absent | remote | on_leave
    workMinutes: integer("work_minutes").notNull().default(0),
    notes: text("notes"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [
    index("attendance_tenant_date_idx").on(t.tenantId, t.date),
    uniqueIndex("attendance_emp_date_idx").on(t.tenantId, t.employeeId, t.date),
  ]
);

export const leaveRequests = pgTable(
  "leave_requests",
  {
    id: serial("id").primaryKey(),
    tenantId: integer("tenant_id")
      .notNull()
      .references(() => tenants.id, { onDelete: "cascade" }),
    employeeId: integer("employee_id")
      .notNull()
      .references(() => employees.id, { onDelete: "cascade" }),
    leaveType: text("leave_type").notNull().default("annual"),
    startDate: text("start_date").notNull(),
    endDate: text("end_date").notNull(),
    days: integer("days").notNull(),
    reason: text("reason").notNull(),
    status: text("status").notNull().default("pending"), // pending | approved | rejected
    reviewerName: text("reviewer_name"),
    reviewedAt: timestamp("reviewed_at"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("leave_requests_tenant_idx").on(t.tenantId)]
);

export const payrollRuns = pgTable(
  "payroll_runs",
  {
    id: serial("id").primaryKey(),
    tenantId: integer("tenant_id")
      .notNull()
      .references(() => tenants.id, { onDelete: "cascade" }),
    employeeId: integer("employee_id")
      .notNull()
      .references(() => employees.id, { onDelete: "cascade" }),
    period: text("period").notNull(), // YYYY-MM
    jurisdiction: text("jurisdiction").notNull().default("IN"),
    statutoryLabel: text("statutory_label").notNull().default("PF/ESI & TDS"),
    baseSalaryCents: bigint("base_salary_cents", { mode: "number" }).notNull(),
    allowancesCents: bigint("allowances_cents", { mode: "number" }).notNull(),
    statutoryDeductionCents: bigint("statutory_deduction_cents", { mode: "number" }).notNull(),
    taxDeductionCents: bigint("tax_deduction_cents", { mode: "number" }).notNull(),
    netPayCents: bigint("net_pay_cents", { mode: "number" }).notNull(),
    status: text("status").notNull().default("processed"), // processed | paid
    paidAt: timestamp("paid_at"),
    transactionId: integer("transaction_id").references(() => transactions.id, {
      onDelete: "set null",
    }),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [
    index("payroll_tenant_idx").on(t.tenantId),
    uniqueIndex("payroll_emp_period_idx").on(t.tenantId, t.employeeId, t.period),
  ]
);

// ============================================================================
// 8. PROJECT & TASK MANAGEMENT
// ============================================================================

export const projects = pgTable(
  "projects",
  {
    id: serial("id").primaryKey(),
    tenantId: integer("tenant_id")
      .notNull()
      .references(() => tenants.id, { onDelete: "cascade" }),
    customerId: integer("customer_id").references(() => customers.id, {
      onDelete: "set null",
    }),
    code: text("code").notNull(),
    name: text("name").notNull(),
    description: text("description"),
    budgetCents: bigint("budget_cents", { mode: "number" }).notNull().default(0),
    spentCents: bigint("spent_cents", { mode: "number" }).notNull().default(0),
    status: text("status").notNull().default("active"), // planning | active | delayed | on_hold | completed
    startDate: text("start_date").notNull(),
    deadline: text("deadline").notNull(),
    teamMembers: jsonb("team_members").$type<string[]>().notNull().default([]),
    ownerName: text("owner_name").notNull(),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => [index("projects_tenant_idx").on(t.tenantId)]
);

export const tasks = pgTable(
  "tasks",
  {
    id: serial("id").primaryKey(),
    tenantId: integer("tenant_id")
      .notNull()
      .references(() => tenants.id, { onDelete: "cascade" }),
    projectId: integer("project_id").references(() => projects.id, {
      onDelete: "cascade",
    }),
    title: text("title").notNull(),
    description: text("description"),
    assigneeUserId: integer("assignee_user_id").references(() => users.id, {
      onDelete: "set null",
    }),
    assigneeName: text("assignee_name"),
    priority: text("priority").notNull().default("medium"), // low | medium | high | urgent
    status: text("status").notNull().default("todo"), // todo | in_progress | review | done
    dueDate: text("due_date"),
    attachmentDocumentId: integer("attachment_document_id").references(
      () => documents.id,
      { onDelete: "set null" }
    ),
    createdByUserId: integer("created_by_user_id").references(() => users.id, {
      onDelete: "set null",
    }),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => [
    index("tasks_tenant_idx").on(t.tenantId),
    index("tasks_project_idx").on(t.tenantId, t.projectId),
  ]
);

export const taskComments = pgTable(
  "task_comments",
  {
    id: serial("id").primaryKey(),
    tenantId: integer("tenant_id")
      .notNull()
      .references(() => tenants.id, { onDelete: "cascade" }),
    taskId: integer("task_id")
      .notNull()
      .references(() => tasks.id, { onDelete: "cascade" }),
    userId: integer("user_id").references(() => users.id, { onDelete: "set null" }),
    authorName: text("author_name").notNull(),
    content: text("content").notNull(),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("task_comments_task_idx").on(t.tenantId, t.taskId)]
);

// ============================================================================
// 9. WORKFLOW AUTOMATION ENGINE
// ============================================================================

export interface WorkflowCondition {
  field: string;
  operator: "eq" | "neq" | "gt" | "lt" | "contains";
  value: string | number;
}

export interface WorkflowAction {
  type:
    | "notify"
    | "create_task"
    | "send_invoice_reminder"
    | "delay"
    | "require_approval"
    | "log_audit";
  targetRole?: string;
  title?: string;
  message?: string;
  priority?: string;
  delayMinutes?: number;
}

export const workflows = pgTable(
  "workflows",
  {
    id: serial("id").primaryKey(),
    tenantId: integer("tenant_id")
      .notNull()
      .references(() => tenants.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    description: text("description"),
    triggerEvent: text("trigger_event").notNull(), // lead.created | invoice.overdue | stock.low | leave.requested | task.overdue | invoice.paid | schedule.daily
    scheduleExpression: text("schedule_expression"),
    conditions: jsonb("conditions").$type<WorkflowCondition[]>().notNull().default([]),
    actions: jsonb("actions").$type<WorkflowAction[]>().notNull().default([]),
    approvalStatus: text("approval_status").notNull().default("pending_approval"), // draft | pending_approval | approved
    approvedByName: text("approved_by_name"),
    isEnabled: boolean("is_enabled").notNull().default(false),
    generatedByAi: boolean("generated_by_ai").notNull().default(false),
    retryLimit: integer("retry_limit").notNull().default(2),
    runCount: integer("run_count").notNull().default(0),
    lastRunAt: timestamp("last_run_at"),
    createdByUserId: integer("created_by_user_id").references(() => users.id, {
      onDelete: "set null",
    }),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => [index("workflows_tenant_idx").on(t.tenantId)]
);

export const workflowExecutions = pgTable(
  "workflow_executions",
  {
    id: serial("id").primaryKey(),
    tenantId: integer("tenant_id")
      .notNull()
      .references(() => tenants.id, { onDelete: "cascade" }),
    workflowId: integer("workflow_id")
      .notNull()
      .references(() => workflows.id, { onDelete: "cascade" }),
    workflowName: text("workflow_name").notNull(),
    triggerEvent: text("trigger_event").notNull(),
    status: text("status").notNull().default("completed"), // completed | awaiting_approval | scheduled | failed
    attemptCount: integer("attempt_count").notNull().default(1),
    triggerPayload: jsonb("trigger_payload")
      .$type<Record<string, unknown>>()
      .notNull()
      .default({}),
    stepLogs: jsonb("step_logs")
      .$type<Array<{ step: string; status: string; detail: string; at: string }>>()
      .notNull()
      .default([]),
    errorMessage: text("error_message"),
    startedAt: timestamp("started_at").notNull().defaultNow(),
    completedAt: timestamp("completed_at"),
  },
  (t) => [index("workflow_exec_tenant_idx").on(t.tenantId)]
);

// ============================================================================
// 10. NOTIFICATIONS, OPSPILOT AI & BILLING
// ============================================================================

export const notifications = pgTable(
  "notifications",
  {
    id: serial("id").primaryKey(),
    tenantId: integer("tenant_id")
      .notNull()
      .references(() => tenants.id, { onDelete: "cascade" }),
    userId: integer("user_id").references(() => users.id, { onDelete: "cascade" }),
    targetRole: text("target_role"),
    title: text("title").notNull(),
    message: text("message").notNull(),
    type: text("type").notNull().default("info"), // info | success | warning | alert | automation
    link: text("link"),
    isRead: boolean("is_read").notNull().default(false),
    emailQueued: boolean("email_queued").notNull().default(false),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("notifications_tenant_idx").on(t.tenantId, t.isRead)]
);

export interface AiPendingAction {
  id: string;
  actionType: "send_overdue_reminders" | "create_task" | "create_workflow_draft";
  summary: string;
  payload: Record<string, unknown>;
  status: "pending" | "confirmed" | "cancelled";
}

export const aiMessages = pgTable(
  "ai_messages",
  {
    id: serial("id").primaryKey(),
    tenantId: integer("tenant_id")
      .notNull()
      .references(() => tenants.id, { onDelete: "cascade" }),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    role: text("role").notNull(), // user | assistant
    content: text("content").notNull(),
    toolsUsed: jsonb("tools_used").$type<string[]>().notNull().default([]),
    structuredData: jsonb("structured_data")
      .$type<Record<string, unknown> | null>()
      .default(null),
    pendingAction: jsonb("pending_action").$type<AiPendingAction | null>().default(null),
    tokensUsed: integer("tokens_used").notNull().default(0),
    provider: text("provider").notNull().default("deterministic"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("ai_messages_tenant_user_idx").on(t.tenantId, t.userId)]
);

export const billingEvents = pgTable(
  "billing_events",
  {
    id: serial("id").primaryKey(),
    tenantId: integer("tenant_id")
      .notNull()
      .references(() => tenants.id, { onDelete: "cascade" }),
    previousPlan: text("previous_plan").notNull(),
    newPlan: text("new_plan").notNull(),
    amountInr: integer("amount_inr").notNull().default(0),
    description: text("description").notNull(),
    actorName: text("actor_name").notNull(),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("billing_events_tenant_idx").on(t.tenantId)]
);
