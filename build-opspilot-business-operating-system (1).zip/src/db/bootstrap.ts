import fs from "node:fs";
import path from "node:path";
import { sql } from "drizzle-orm";
import { db, pool } from "@/db";
import { ensureSeeded } from "@/db/seed";

let bootstrapPromise: Promise<void> | null = null;

async function runBootstrapOnce(): Promise<void> {
  const check = await db.execute(
    sql`SELECT to_regclass('public.tenants') AS exists`
  );
  const row = check.rows[0] as { exists?: string | null } | undefined;

  if (!row?.exists) {
    const drizzleDir = path.join(process.cwd(), "drizzle");
    if (fs.existsSync(drizzleDir)) {
      const sqlFiles = fs
        .readdirSync(drizzleDir)
        .filter((f) => f.endsWith(".sql"))
        .sort();

      for (const file of sqlFiles) {
        const raw = fs.readFileSync(path.join(drizzleDir, file), "utf8");
        const statements = raw
          .split("--> statement-breakpoint")
          .map((s) => s.trim())
          .filter(Boolean);

        for (const stmt of statements) {
          try {
            await pool.query(stmt);
          } catch (err) {
            const code = (err as { code?: string })?.code;
            // Ignore duplicate table/index/constraint errors on concurrent boot
            if (code !== "42P07" && code !== "42710") {
              throw err;
            }
          }
        }
      }
    }
  }

  await ensureSeeded();
}

export async function ensureDatabaseReady(): Promise<void> {
  if (!bootstrapPromise) {
    bootstrapPromise = runBootstrapOnce().catch((err) => {
      bootstrapPromise = null;
      throw err;
    });
  }
  await bootstrapPromise;
}
