# OpsPilot — Your Entire Business. One Operating System.

OpsPilot is a production-oriented, multi-tenant, AI-powered Business Operating System unifying 13 operational domains inside a single workspace:

1. **Executive Dashboard & Analytics** — Real-time revenue, expense, profit, receivables, CRM, HRMS, project & inventory KPIs with 6 chart dimensions and customizable widgets.
2. **CRM & Sales Pipeline** — Customer 360 profiles, communication logs, lead follow-ups, conversion analytics, and 7-stage Kanban deals.
3. **Sales & Invoicing** — Quotations, sales orders, GST/VAT invoices, printable PDFs, discounts, partial payments, refunds, and collection reminders.
4. **Finance & Immutable Ledger** — Income/expense entries, receivables/payables, monthly cash flow & P&L, receipt links, and non-destructive reversing entries.
5. **HRMS & Payroll** — Employee profiles, confidential salary protection, attendance check-in/out, leave approval workflows, and jurisdiction-aware payroll & payslips (`IN`, `US`, `GB`, `SG`, `AE`).
6. **Inventory Control** — Product & service SKUs, stock valuation reports, low-stock alerts, and traceable stock movement audit logs.
7. **Procurement & Vendor Management** — Vendor profiles, purchase orders, approval gates, goods-received inventory sync, and vendor payment ledger posting.
8. **Project & Task Management** — Client project budgets, Kanban/List/Calendar task views, comments, and collaboration alerts.
9. **Document Management Vault** — Validated uploads, previews, version history, role-scoped permissions (`workspace`, `managers`, `hr_only`, `finance_only`), and expiration reminders.
10. **OpsPilot Intelligence (AI)** — Permission-aware conversational assistant backed by deterministic database queries (zero fabricated financial figures), executive reports, anomaly detection, invoice/receipt extraction, optional BYO LLM providers (AES-256-GCM encrypted keys), token usage tracking, and human confirmation gates.
11. **Workflow Automation Engine** — Visual & natural-language workflow drafts, triggers, conditions, delays, retries, approval gates, scheduled health sweeps, and execution history.
12. **Global Search & Notification Center** — `⌘K` instant tenant-scoped search across 7 entity classes plus in-app/email-ready notifications and user preferences.
13. **Multi-Tenancy, RBAC & Commercial Billing** — Isolated workspaces, 7 configurable roles, workspace invitations, immutable audit trail, and configurable tiers (**Community Free**, **Starter ₹101**, **Pro ₹499/mo**, **Business ₹1,499/mo**, **Custom**).

---

## Architecture & Stack

- **Application & API**: Next.js 16 (App Router), React 19, TypeScript 5, Zod validation
- **UI & Visualization**: Tailwind CSS v4 (Light & Dark themes), Recharts, Lucide icons, custom OpsPilot SVG identity
- **Database & ORM**: PostgreSQL 16 + Drizzle ORM (`src/db/schema.ts`, 26 normalized tables, strict `tenant_id` scoping)
- **Security**: `bcryptjs` password hashing, SHA-256 hashed HttpOnly sessions, timing-safe CSRF tokens, AES-256-GCM secret encryption, MIME/extension upload allowlisting, sliding-window rate limits, immutable audit logs
- **DevOps**: `Dockerfile`, `docker-compose.yml` (PostgreSQL + Redis + App), `scripts/backup-db.sh`, GitHub Actions CI (`.github/workflows/ci.yml`)

---

## Quick Start (Local Installation)

```bash
# 1. Configure environment
cp .env.example .env

# 2. Install dependencies
npm install

# 3. Apply PostgreSQL schema and seed sample isolated workspaces
npx drizzle-kit push --force
npx tsx src/db/seed.ts

# 4. Build and start
npm run build
npm run start
```

Open `http://localhost:3000`.

### Demo Accounts (Seeded Multi-Tenant Sandbox)
Password for all demo accounts: `OpsPilot!2026`
- **Owner (Tenant 1 — Meridian Digital & Commerce)**: `arjun@meridianstudio.in`
- **Accountant (Tenant 1)**: `kavya@meridianstudio.in`
- **HR Manager (Tenant 1)**: `ananya@meridianstudio.in`
- **Salesperson (Tenant 1)**: `rohan@meridianstudio.in`
- **Employee (Tenant 1 — Restricted RBAC)**: `dev@meridianstudio.in`
- **Owner (Tenant 2 — Northstar Consulting Labs)**: `priya@northstarlabs.in`

---

## Running Automated Tests

With the server running on `http://127.0.0.1:3000`:

```bash
npx tsx tests/opspilot.test.ts
```

---

## Additional Documentation

- [REST API Reference](docs/API.md)
- [Security & Multi-Tenant Isolation](docs/SECURITY.md)
- [Deployment & Backup Guide](docs/DEPLOYMENT.md)
- [Changelog & Known Unfinished Items](CHANGELOG.md)
