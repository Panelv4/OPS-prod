# OpsPilot Changelog & Engineering Log

## v1.0.0 — Initial Full Release (2026)

### Delivered Phases
- **Phase 1–2**: Project foundation, light/dark executive design system, custom OpsPilot SVG brand identity, 26-table multi-tenant PostgreSQL schema, bcrypt/SHA-256/CSRF session authentication, password recovery, workspace invitations, 7-role configurable RBAC matrix, and customizable analytics dashboard.
- **Phase 3–4**: Complete CRM (customers, communication timeline, 7-stage Kanban pipeline, follow-ups, conversion analytics), Sales & Invoicing (quotations, sales orders, tax invoices, printable PDF view, deterministic integer-cents math, partial payments, refunds, reminders), and immutable Finance ledger (income/expense, receivables/payables, monthly cash flow, P&L, reversing entries).
- **Phase 5–6**: HRMS (employees, confidential salary redaction, attendance check-in/out, leave requests & approvals, multi-jurisdiction payroll & printable payslips), Projects & Tasks (budgets, Kanban/List/Calendar views, comments), Inventory (catalog SKUs, valuation reports, traceable stock movements, low-stock alerts), and Procurement (vendors, PO approvals, goods-received stock sync, vendor payouts).
- **Phase 7–9**: Document Vault (MIME/extension-validated uploads, previews, versioning, visibility scopes, expiry alerts), Global `⌘K` Search & Notification Center, OpsPilot Intelligence AI (permission-scoped deterministic query tools, anomaly detection, executive reports, receipt extraction, AES-256-GCM BYO LLM keys, human confirmation gates), and Workflow Automation Engine (visual & NL draft builder, approval requirement, conditions, delays, retries, scheduled sweeps, execution logs).
- **Phase 10–11**: Configurable commercial billing (Community Free, Starter ₹101, Pro ₹499/mo, Business ₹1,499/mo, Custom), usage telemetry, Dockerfile, docker-compose, backup script, GitHub Actions CI, documentation, and verified automated test suite.

### Transparent List of Unfinished / External-Credential Features
1. **Live Payment Gateway Settlement (Razorpay / Stripe)**: Plan selection, usage enforcement, configurable pricing, and billing audit logs work end-to-end; live card/UPI charging requires merchant API credentials and webhook onboarding.
2. **Live Outbound SMTP Email Delivery**: Email verification tokens, password reset tokens, and notification email-queue flags are fully architected; actual SMTP socket dispatch requires customer `SMTP_HOST` credentials.
3. **External S3 Bucket Binary Offload & Distributed Worker Daemon**: Documents are validated, versioned, and stored securely in PostgreSQL for zero-config reliability; high-volume binary offload to external S3/R2 and external cron triggers for `schedule.daily` require external bucket credentials and host scheduler setup.
4. **Optical OCR on Scanned Image Receipts**: Deterministic text/invoice extraction and ledger posting work out of the box; binary raster OCR requires attaching a vision-capable LLM API key.
