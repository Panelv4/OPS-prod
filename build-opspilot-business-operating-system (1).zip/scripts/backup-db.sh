#!/usr/bin/env bash
set -euo pipefail

# OpsPilot PostgreSQL Backup Utility
# Usage: DATABASE_URL=postgresql://... ./scripts/backup-db.sh [output_dir]

DB_URL="${DATABASE_URL:-postgresql://postgres:postgres@127.0.0.1:5432/app_db}"
OUT_DIR="${1:-./backups}"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT_FILE="${OUT_DIR}/opspilot-${STAMP}.sql.gz"

mkdir -p "${OUT_DIR}"
pg_dump "${DB_URL}" --no-owner --no-privileges | gzip -9 > "${OUT_FILE}"
echo "Backup written: ${OUT_FILE} ($(du -h "${OUT_FILE}" | cut -f1))"
