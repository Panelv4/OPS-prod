# OpsPilot Deployment Guide

## Preview access is not public deployment

A generated `https://3000-<sandbox-id>.e2b.app` address is a temporary sandbox endpoint, **not a permanent public production domain**. It may be access-controlled by the platform even while the application builds successfully and responds to local health checks.

### `403 Forbidden: Missing traffic access token`

This response comes from the E2B gateway **before the request reaches Next.js**. A private sandbox requires the `e2b-traffic-access-token` request header. This is infrastructure authentication, separate from OpsPilot login sessions and CSRF tokens.

- Use the development platform's authenticated Preview interface, where available, rather than opening the raw sandbox hostname directly.
- If the integrated Preview also reports this error, the platform owner must repair its authenticated preview proxy or sandbox configuration. Application headers, cookies, CORS changes, and another build cannot authorize traffic through that gateway.
- Only the sandbox/project owner controls the access policy. Do not expose a traffic access token in frontend source, URL parameters, or a public repository. Do not make every sandbox service public merely to share the app.
- For a link that ordinary visitors can open, deploy the app to your own hosting account using an option below and use that provider's assigned hostname or your custom domain. A public production deployment is not created by starting a sandbox preview.

See the official [E2B public traffic access documentation](https://docs.e2b.dev/network/restrict-public-access) for owner-side settings and authenticated access requirements.

---

OpsPilot is a standard Next.js 16 (App Router) + PostgreSQL 16 application. It can be deployed on serverless cloud platforms (Vercel + Neon/Supabase), managed container platforms (Railway, Render, Fly.io, Coolify), or any Linux VPS with Docker Compose.

On first boot, calling `/api/health` (or registering/signing in) automatically applies the bundled SQL schema from `drizzle/` and initializes the database if empty.

---

## Required & Optional Environment Variables

| Variable | Required | Description |
|---|---|---|
| `DATABASE_URL` | **Yes** | PostgreSQL connection string (`postgresql://user:pass@host:5432/dbname`) |
| `OPSPILOT_SECRET_KEY` | **Yes** | 64-character hex secret for AES-256-GCM encryption (`openssl rand -hex 32`) |
| `OPENAI_API_KEY` | Optional | Server-level OpenAI key (users can also add encrypted workspace keys in `/app/ai`; deterministic AI works without any key) |
| `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`, `SMTP_FROM` | Optional | Outbound SMTP credentials for email delivery |
| `REDIS_URL` | Optional | Redis URI when running multi-node deployments |
| `S3_ENDPOINT`, `S3_BUCKET`, `S3_ACCESS_KEY`, `S3_SECRET_KEY` | Optional | S3-compatible object storage credentials |

---

## Option 1: Vercel + Managed PostgreSQL (Neon or Supabase)

1. Push this project to a GitHub repository.
2. Provision a PostgreSQL database on **Neon** or **Supabase** and copy its `DATABASE_URL`.
3. Import the GitHub repository in **Vercel** (`Framework Preset: Next.js`).
4. Add `DATABASE_URL` and `OPSPILOT_SECRET_KEY` under **Project Settings → Environment Variables**.
5. Click **Deploy**.
6. Initialize the schema by either opening `https://your-domain.com/api/health` once or running locally:
   ```bash
   npx drizzle-kit push --dialect=postgresql --schema=./src/db/schema.ts --url="$DATABASE_URL"
   DATABASE_URL="$DATABASE_URL" npx tsx src/db/seed.ts
   ```

---

## Option 2: Railway / Render / Coolify (Managed Docker)

1. Push this repository to GitHub.
2. Create a new project in **Railway** (or **Render** / **Coolify**) and add a **PostgreSQL** service.
3. Add a **Web Service** linked to your GitHub repo (it will automatically detect the root `Dockerfile`).
4. Set environment variables:
   - `DATABASE_URL` → link to your PostgreSQL service URL
   - `OPSPILOT_SECRET_KEY` → output of `openssl rand -hex 32`
   - `PORT` → `3000`
5. Set the Health Check Path to `/api/health` and deploy. The built-in healthcheck automatically initializes the database schema on first start.

---

## Option 3: Self-Hosted Linux VPS (Docker Compose + HTTPS)

Recommended for Ubuntu 22.04/24.04 on DigitalOcean, Hetzner, AWS EC2, or Hostinger (2 vCPU / 2 GB RAM+).

```bash
# 1. Copy or clone the project onto your server
git clone <your-repo-url> opspilot && cd opspilot

# 2. Configure production secrets
cp .env.example .env
# Edit .env and set strong values for:
#   POSTGRES_PASSWORD=<strong-db-password>
#   POSTGRES_DB=opspilot
#   OPSPILOT_SECRET_KEY=$(openssl rand -hex 32)

# 3. Build and launch PostgreSQL, Redis, and OpsPilot
docker compose up -d --build

# 4. Verify health & auto-bootstrap schema
curl -f http://127.0.0.1:3000/api/health
```

### Enable Automatic HTTPS with Caddy

Point your domain's DNS `A` record to your server IP, install Caddy, and add to `/etc/caddy/Caddyfile`:

```caddyfile
ops.yourdomain.com {
    reverse_proxy 127.0.0.1:3000
}
```

Reload Caddy (`sudo systemctl reload caddy`). Caddy automatically provisions Let's Encrypt TLS certificates and forwards `X-Forwarded-Proto: https` so OpsPilot sets `Secure` session cookies.

---

## Production Hardening & Automated Backups

- **Remove Demo Accounts (Optional)**: If you want a clean production database without demo workspaces, delete the seeded demo tenants after creating your own Owner workspace at `/register`:
  ```sql
  DELETE FROM tenants WHERE slug IN ('meridian-ops', 'northstar-labs');
  DELETE FROM users WHERE email LIKE '%@meridianstudio.in' OR email LIKE '%@northstarlabs.in';
  ```
- **Nightly Encrypted Backups**: Schedule `scripts/backup-db.sh` via cron:
  ```cron
  0 2 * * * DATABASE_URL="postgresql://..." /opt/opspilot/scripts/backup-db.sh /var/backups/opspilot
  ```
