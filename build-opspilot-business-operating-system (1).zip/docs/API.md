# OpsPilot REST API Documentation

All authenticated endpoints require an active `opspilot_session` HttpOnly cookie. State-mutating requests (`POST`, `PATCH`, `PUT`, `DELETE`) additionally require the session's `x-csrf-token` header (returned by `GET /api/auth/me` and auth endpoints). Every record query is strictly scoped to the session's active `tenant_id`.

## Health & Identity
| Method | Endpoint | Permission | Purpose |
|---|---|---|---|
| `GET` | `/api/health` | Public | Liveness & PostgreSQL connectivity probe |
| `POST` | `/api/auth/register` | Public (rate-limited) | Register user + create isolated workspace or accept invite code |
| `POST` | `/api/auth/login` | Public (rate-limited) | Authenticate credentials and issue HttpOnly session + CSRF token |
| `POST` | `/api/auth/logout` | Session | Revoke server-side session and clear cookie |
| `GET` | `/api/auth/me` | Session | Current user, active workspace, permissions, CSRF token, unread count |
| `PATCH` | `/api/auth/me` | Session | Update profile, change password, verify email token, update notification prefs |
| `POST` | `/api/auth/password-reset` | Public (rate-limited) | Request (`step: "request"`) or confirm (`step: "confirm"`) password reset |

## Workspace, Team & RBAC
| Method | Endpoint | Permission | Purpose |
|---|---|---|---|
| `GET` | `/api/workspace` | Session | Workspace settings, usage meters, members, invitations, RBAC matrix & audit logs |
| `PATCH` | `/api/workspace` | Action-specific | Update settings, role permission matrix, AI config, dashboard widgets, or switch/create workspace |
| `POST` | `/api/workspace/members` | `workspace:users` | Generate single-use SHA-256 verified team invitation |
| `PATCH` | `/api/workspace/members` | `workspace:users` | Update member role or active/suspended status |
| `DELETE` | `/api/workspace/members?invitationId=` | `workspace:users` | Revoke pending workspace invitation |

## Core Business Modules
| Method | Endpoint | Permission | Purpose |
|---|---|---|---|
| `GET` | `/api/dashboard` | `dashboard:view` | Executive KPIs, 6 chart time-series, inventory alerts & audit activity |
| `GET/POST/PATCH/DELETE` | `/api/crm/customers` | `crm:view` / `crm:write` / `crm:delete` | Customer profiles, 360° purchase history & communication logs |
| `GET/POST/PATCH/DELETE` | `/api/crm/leads` | `crm:view` / `crm:write` | Leads, Kanban pipeline transitions, customer conversion & `lead.created` triggers |
| `GET/POST/PATCH` | `/api/sales/invoices` | `sales:view` / `sales:write` / `sales:refund` | Quotations, sales orders, tax invoices, partial payments, refunds & reminders |
| `GET/POST/PATCH` | `/api/finance` | `finance:view` / `finance:write` / `finance:reverse` | Immutable ledger, receivables/payables, P&L, cash flow & reversing entries |
| `GET/POST/PATCH` | `/api/hrms` | `hrms:view` / `hrms:write` / `hrms:payroll` | Employees (confidentiality-filtered), attendance, leave workflows & jurisdiction payroll |
| `GET/POST/PATCH` | `/api/inventory` | `inventory:view` / `inventory:write` / `inventory:adjust` | Catalog SKUs, stock valuation reports & traceable stock movement logs |
| `GET/POST/PATCH` | `/api/procurement` | `procurement:view` / `procurement:write` / `procurement:approve` | Vendors, purchase orders, PO approvals, goods receipt inventory sync & vendor payouts |
| `GET/POST/PATCH/DELETE` | `/api/projects` | `projects:view` / `projects:write` | Projects, Kanban/List/Calendar tasks & team comments |
| `GET/POST/DELETE` | `/api/documents` | `documents:view` / `documents:write` | Validated document upload, role-restricted download, previews, versioning & expiry |
| `GET` | `/api/search?q=` | Session (per-module RBAC) | Cross-module tenant-isolated search across 7 record types |
| `GET/PATCH` | `/api/notifications` | Session | In-app notifications and mark-read controls |
| `GET/POST` | `/api/ai` | `ai:use` (rate-limited) | Verified business assistant, anomaly insights, receipt extractor & human confirmations |
| `GET/POST/PATCH/DELETE` | `/api/automations` | `automation:view` / `write` / `approve` | Visual & NL workflow drafts, governance approval, test/scheduled runs & history |
| `GET/POST` | `/api/billing` | Session / `workspace:billing` | Commercial plans, tenant usage telemetry, plan switching & configurable pricing |
