# OpsPilot Security Architecture & Verification

This document records the concrete security controls implemented and verified by automated tests in `tests/opspilot.test.ts` (no unverified compliance certifications are claimed).

1. **Password Security**: Passwords hashed via `bcryptjs` (cost factor 10) with enforced minimum length and complexity validation (`validatePasswordStrength`).
2. **Session & Token Hygiene**: Opaque 256-bit random session, invitation, email verification, and password reset tokens are stored exclusively as SHA-256 digests. Cookies use `HttpOnly`, `SameSite=Lax`, and `Secure` over HTTPS. Password resets revoke all active user sessions.
3. **CSRF Protection**: Every session has a unique cryptographic `csrfToken`. All mutating API routes verify `x-csrf-token` via `crypto.timingSafeEqual` and reject missing/mismatched tokens with `403 Forbidden`.
4. **Tenant Isolation**: Every business table contains a foreign-key `tenant_id`. Every `SELECT`, `UPDATE`, and `DELETE` binds `eq(table.tenantId, ctx.tenantId)` from the verified server session — never trusting client-supplied tenant IDs. Verified via automated cross-tenant intrusion tests.
5. **Role-Based Access Control (RBAC)**: 7 built-in roles (`owner`, `administrator`, `manager`, `hr_manager`, `accountant`, `salesperson`, `employee`) mapped across 35 granular permissions, customizable per workspace. Employee salaries and confidential HR notes are automatically redacted for non-privileged roles; restricted documents enforce visibility scopes on preview, listing, and download.
6. **SQL Injection & XSS Prevention**: All database operations use parameterized Drizzle ORM queries; inputs are validated with Zod and null-byte sanitized; React auto-escapes rendered output; HTTP response headers enforce `X-Content-Type-Options: nosniff`, `X-Frame-Options: SAMEORIGIN`, and `Referrer-Policy`.
7. **Secure File Uploads**: `validateUploadFile` enforces a strict MIME allowlist, 5 MB payload cap, filename sanitization, and blocks executable/script extensions (`.exe`, `.sh`, `.js`, `.html`, `.svg`, `.php`, `.py`). Downloads serve `Content-Disposition: attachment` + `nosniff`.
8. **Secret Management**: Tenant BYO LLM API keys are encrypted at rest with AES-256-GCM (`encryptSecret`/`decryptSecret`) and are never returned by API endpoints.
9. **Financial & Audit Integrity**: All monetary values use deterministic integer minor units (paise/cents). Ledger transactions, stock movements, and audit logs are append-only; corrections post explicit reversing entries.
10. **AI Guardrails**: OpsPilot Intelligence executes permission-checked database queries for all numbers, tracks token quotas, rate-limits requests, and requires explicit human confirmation before executing state-changing actions or enabling AI-drafted workflows.
11. **Backups & Dependency Scanning**: `scripts/backup-db.sh` creates compressed `pg_dump` snapshots; CI executes `npm audit`.
